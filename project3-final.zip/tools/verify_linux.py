"""Linux resource check for the frozen export; never edits official files.

Limits: four allowed logical CPUs, inherited 2 GiB RLIMIT_AS per process,
180 seconds for the complete official check/predict/score wrapper.
Aggregate process-tree VmSize/RSS are additionally sampled, not hard capped.
"""
import argparse,hashlib,json,os,platform,signal,subprocess,sys,time
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--official-root',type=Path,required=True)
    p.add_argument('--export-root',type=Path,required=True)
    p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--split',choices=['validation','test'],default='validation')
    p.add_argument('--allow-test',action='store_true')
    args=p.parse_args()
    if sys.platform!='linux':p.error('Run inside Linux/WSL2, using Linux Python.')
    if args.split=='test' and not args.allow_test:p.error('Explicit --allow-test is required for an additional full test run.')
    import resource
    official=args.official_root.resolve();export=args.export_root.resolve();out=args.output_dir.resolve()
    if out.is_relative_to(official) or out.is_relative_to(export):p.error('Keep new outputs outside the immutable official/export directories.')
    import sqlglot
    if sqlglot.__version__!='27.29.0':p.error('Install sqlglot==27.29.0 before the offline run.')
    freeze=json.loads((export/'source-freeze.json').read_text(encoding='utf-8'))
    for name,value in freeze.items():
        path=export/'submission'/Path(name.replace('\\','/'))
        if hashlib.sha256(path.read_bytes()).hexdigest()!=value:p.error('Source freeze mismatch: '+name)
    release=json.loads((official/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
    for name,info in release['files'].items():
        if hashlib.sha256((official/name).read_bytes()).hexdigest()!=info['sha256']:p.error('Official file mismatch: '+name)
    cpus=sorted(os.sched_getaffinity(0))[:4]
    if len(cpus)!=4:p.error('Four logical CPUs must be available.')
    out.mkdir(parents=True,exist_ok=True)
    marker=out/('test-started.json' if args.split=='test' else 'validation-started.json')
    with marker.open('x',encoding='utf-8') as f:json.dump(dict(split=args.split,source_freeze_sha256=hashlib.sha256((export/'source-freeze.json').read_bytes()).hexdigest(),started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())),f,indent=2)
    def constrain():
        os.sched_setaffinity(0,cpus)
        resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
    command=[sys.executable,str(export/'submission/run_evaluation.py'),'--official-root',str(official),'--output-dir',str(out),'--label','linux','--split',args.split]
    env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
    peak_vm=peak_rss=0;timed_out=False;started=time.monotonic()
    with (out/'resource-run.log').open('w',encoding='utf-8') as log:
        proc=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=constrain)
        while proc.poll() is None:
            if time.monotonic()-started>180:
                timed_out=True;os.killpg(proc.pid,signal.SIGKILL);break
            # Select all members of the new process group, including SQL workers.
            vm=rss=0
            for directory in Path('/proc').iterdir():
                if not directory.name.isdigit():continue
                try:
                    stat=(directory/'stat').read_text();rest=stat[stat.rfind(')')+2:].split()
                    if int(rest[2])!=proc.pid:continue
                    status=(directory/'status').read_text().splitlines()
                    for line in status:
                        if line.startswith('VmSize:'):vm+=int(line.split()[1])*1024
                        if line.startswith('VmRSS:'):rss+=int(line.split()[1])*1024
                except (FileNotFoundError,ProcessLookupError,PermissionError,ValueError):continue
            peak_vm=max(peak_vm,vm);peak_rss=max(peak_rss,rss);time.sleep(.05)
        code=proc.wait()
    wall=time.monotonic()-started;usage=resource.getrusage(resource.RUSAGE_CHILDREN)
    result=dict(platform=platform.platform(),python=sys.version,sqlglot=sqlglot.__version__,split=args.split,logical_cpus=cpus,as_limit_bytes_per_process=2*1024**3,wall_limit_seconds=180,wall_seconds=wall,cpu_seconds=usage.ru_utime+usage.ru_stime,largest_waited_process_peak_rss_kib=usage.ru_maxrss,sampled_process_tree_peak_vm_bytes=peak_vm,sampled_process_tree_peak_rss_bytes=peak_rss,sampling_seconds=.05,timeout=timed_out,returncode=code,command=command,network_namespace=os.readlink('/proc/self/ns/net'))
    if code==0:
        score=json.loads((out/f'linux-{args.split}-score.json').read_text(encoding='utf-8'))
        result.update(n=score['n'],correct=score['correct'],accuracy=score['accuracy'])
    result['official_files_unchanged']=all(hashlib.sha256((official/n).read_bytes()).hexdigest()==v['sha256'] for n,v in release['files'].items())
    result['completed_under_limits']=code==0 and not timed_out and wall<=180 and result['official_files_unchanged']
    (out/'resource-summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
    return 0 if result['completed_under_limits'] else 1

if __name__=='__main__':raise SystemExit(main())
