This directory contains the frozen CPU Agent, report, training algorithm/records, and official outputs. It depends only on SQLGlot 27.29.0; there is no live LLM and no LoRA.

## Linux offline reproduction

Prepare Python 3.12, SQLGlot 27.29.0, and the original course package in advance. Run the following in the directory where the source ZIP is extracted, replacing the path with the official package directory containing `mp3_sql`:

```
export PYTHONUTF8=1 PYTHONDONTWRITEBYTECODE=1
python submission/run_evaluation.py --official-root /path/to/MP3_SQL_student_package --output-dir reproduced --label final --split test
```

The script invokes the original `check_data`, `predict`, and `score`, uses 4 workers, and does not modify the official directory. Reproduced outputs are in `reproduced/test.json` and `test-score.json`. On Windows PowerShell, replace `python` with the full path to the `python.exe` that has the dependencies installed and invoke the same script with `&`.

## Validation and ablations (do not use test)

```
python submission/run_evaluation.py --official-root /path/to/MP3_SQL_student_package --output-dir reproduced --label full --split validation
python submission/run_evaluation.py --official-root /path/to/MP3_SQL_student_package --output-dir reproduced --label early-off --split validation --checkpoint ablations/early-off.json
python ablations/make_tree_only.py --source submission --output scratch/tree-only
python scratch/tree-only/run_evaluation.py --official-root /path/to/MP3_SQL_student_package --output-dir reproduced --label tree-only --split validation
PYTHONPATH="submission:/path/to/MP3_SQL_student_package" python -m unittest discover -s submission/tests -q
```

The frozen configuration can be enabled by default by `create_agent()`, or `submission/config.json` can be passed. The full test must retain the official scoring for all 240 tasks and three instances; ablation scores cannot be used as a substitute.

## Training records

`training/` contains the actual fitting algorithm, configuration and logs, input/source SHA values, and validation results; the dataset and training cache are not packaged according to the export rules. The delivered parameters have already been generated, and inference does not require retraining. For training input sources and algorithm descriptions, see `training/README.md`.

## Linux limit verification

Run the following in the root directory of the extracted export package; the output directory must be outside the official package and the export package:

```
python tools/verify_linux.py --official-root /path/to/MP3_SQL_student_package --export-root "$PWD" --output-dir /tmp/mp3-reproduced-linux --split test --allow-test
```

Each new output directory can be used to launch verification for that split only once. The script sets CPU affinity to 4 available logical CPUs, inherits the per-process 2 GiB `RLIMIT_AS` and a 180-second wall-clock timeout for the complete pipeline, and samples the total VmSize/RSS of the process tree. Dependencies should be prepared in advance, and it should be run in a Linux environment disconnected from external networks; the script does not disconnect the network itself and does not automatically enable bubblewrap.

This package includes complete Linux verification results: test 196/240, validation 111/120. Resource statistics and raw commands are located in `outputs/linux-evidence/`. The officially uploaded `outputs/test-score.json` is byte-for-byte from the Linux official scoring, with no modified fields; `outputs/test.json` contains the corresponding full predictions.