import json,shutil,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=Path('submission'));p.add_argument('--output',type=Path,required=True);a=p.parse_args()
shutil.copytree(a.source,a.output);f=a.output/'ranker-model.json';m=json.loads(f.read_text(encoding='utf-8'));t=m['members'][1];t['fallback']=m['fallback'];f.write_text(json.dumps(t),encoding='utf-8')
