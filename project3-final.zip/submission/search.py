"""Schema-independent candidate search. Inputs are public observation data only."""
import re
import difflib
import math
import sqlglot
from sqlglot import exp
from sqlglot.optimizer.scope import traverse_scope
from repairs import align_projection, fix_columns, semantic_candidates, generate_candidates, repair_joins, signature
from synthesis import synthesize
from linking import linked_queries
from mutations import mutations


STOP = set("a an the is are was were what which who whose how many much all of in on at for with and or to from by that have has do does show find list give me return please their its each than as number names name id ids".split())


def words(text):
    raw=set(re.findall(r"[a-z]+", text.lower())) - STOP
    return {w[:-3]+"y" if w.endswith("ies") else w[:-1] if w.endswith("s") else w for w in raw}


def parse(sql):
    try:
        ast = sqlglot.parse_one(sql, read="sqlite")
        if isinstance(ast, (exp.Select, exp.SetOperation)):
            return ast
    except (sqlglot.errors.SqlglotError, ValueError, RecursionError):
        pass
    return None


def extra_candidates(sql, example, question, schema):
    tree = parse(sql)
    if not isinstance(tree, exp.Select):
        return
    q = question.lower()
    fixed = fix_columns(tree, schema)
    aligned = align_projection(fixed, example["columns"], schema)
    for base in [aligned, tree]:
        distinct = base.copy()
        distinct.set("distinct", None if distinct.args.get("distinct") else exp.Distinct())
        yield "distinct", distinct.sql(dialect="sqlite")
        case = base.copy()
        changed = False
        for node in case.walk():
            if isinstance(node, (exp.EQ, exp.NEQ, exp.Like)) and isinstance(node.this, exp.Column) and isinstance(node.expression, exp.Literal) and node.expression.is_string:
                node.set("this", exp.Lower(this=node.this.copy()))
                node.set("expression", exp.Literal.string(node.expression.this.lower()))
                changed = True
            elif isinstance(node, exp.In) and node.expressions and all(isinstance(e, exp.Literal) and e.is_string for e in node.expressions):
                node.set("this", exp.Lower(this=node.this.copy()))
                node.set("expressions", [exp.Literal.string(e.this.lower()) for e in node.expressions])
                changed = True
        if changed:
            yield "case", case.sql(dialect="sqlite")
        exact = base.copy()
        changed = False
        for projection in exact.expressions:
            for count in projection.find_all(exp.Count):
                if not isinstance(count.this, exp.Star):
                    count.set("this", exp.Star())
                    changed = True
        if changed:
            yield "count", exact.sql(dialect="sqlite")
        # Public expression labels disambiguate projection functions and missing outputs.
        exprs = []
        sources = {t.alias_or_name.lower():t.name.lower() for t in base.find_all(exp.Table)}
        columns = {t["name"].lower(): {c["name"].lower() for c in t["columns"]} for t in schema}
        for label in example["columns"]:
            item = None
            try:
                item = sqlglot.parse_one(label, read="sqlite")
            except (sqlglot.errors.SqlglotError, ValueError):
                break
            if not isinstance(item, (exp.Column, exp.AggFunc)):
                break
            valid = True
            for col in item.find_all(exp.Column):
                owners = [alias for alias, table in sources.items() if col.name.lower() in columns.get(table, set())]
                if not owners:
                    valid = False
                    break
                # Retain the source of a matching expression in the existing projection.
                prior = next((c for e in base.expressions for c in e.find_all(exp.Column) if c.name.lower() == col.name.lower()), None)
                col.set("table", exp.to_identifier(prior.table if prior and prior.table else owners[0]))
            if not valid:
                break
            exprs.append(item)
        if len(exprs) == len(example["columns"]):
            projected = base.copy()
            projected.set("expressions", exprs)
            yield "projection", projected.sql(dialect="sqlite")

        # JOIN to a one-to-many relation can bias AVG/SUM over the root entity.
        source = base.args.get("from")
        joins = base.args.get("joins", [])
        if source and isinstance(source.this, exp.Table) and len(joins) == 1 and not base.args.get("where"):
            root = source.this
            if all(not c.table or c.table.lower() == root.alias_or_name.lower() for e in base.expressions for c in e.find_all(exp.Column)):
                on = joins[0].args.get("on")
                if isinstance(on, exp.EQ) and isinstance(on.this, exp.Column) and isinstance(on.expression, exp.Column):
                    left, right = on.this, on.expression
                    if left.table.lower() != root.alias_or_name.lower():
                        left, right = right, left
                    if left.table.lower() == root.alias_or_name.lower():
                        semi = base.copy()
                        semi.set("joins", [])
                        query = exp.select(right.copy()).from_(joins[0].this.copy())
                        semi = semi.where(exp.In(this=left.copy(), query=exp.Subquery(this=query)))
                        yield "semijoin", semi.sql(dialect="sqlite")

        if re.search(r"\b(most|least|greatest|lowest|highest|common|frequent)\b", q):
            if not any(e.find(exp.AggFunc) for e in base.expressions):
                grouped = base.copy()
                grouped.set("group", exp.Group(expressions=[e.unalias().copy() for e in base.expressions]))
                grouped.set("having", None)
                desc = not bool(re.search(r"\b(least|lowest|fewest)\b", q))
                grouped.set("order", exp.Order(expressions=[exp.Ordered(this=exp.Count(this=exp.Star()), desc=desc)]))
                grouped.set("limit", exp.Limit(expression=exp.Literal.number("1")))
                yield "mode", grouped.sql(dialect="sqlite")
                order = base.args.get("order")
                if order and isinstance(order.expressions[0].this, exp.Column):
                    summed = grouped.copy()
                    summed.set("order", exp.Order(expressions=[exp.Ordered(this=exp.Sum(this=order.expressions[0].this.copy()), desc=desc)]))
                    yield "group_sum", summed.sql(dialect="sqlite")


def pool(original, hints, question, example, schema):
    candidates = []
    seen = set()
    def add(sql, origin):
        ast = parse(sql)
        if ast is None or len(sql.encode("utf-8")) > 16000:
            return
        key = ast.sql(dialect="sqlite", comments=False)
        if key not in seen:
            seen.add(key)
            candidates.append({"sql":sql, "key":key, "origin":origin})
    add(original, "original")
    roots = []
    for hint in hints:
        if not isinstance(hint, str):
            continue
        hint = re.sub(r"^```(?:sql|sqlite)?\s*\n|\n```$", "", hint.strip(), flags=re.I)
        before = len(candidates)
        add(hint, "hint")
        if len(candidates) != before:
            roots.append(hint)
    if parse(original):
        roots.append(original)
    for sql in roots:
        ast = parse(sql)
        aligned = align_projection(fix_columns(ast, schema), example["columns"], schema) if isinstance(ast, exp.Select) else ast
        add(aligned.sql(dialect="sqlite"), "align")
        for value in semantic_candidates(sql, example, question, schema):
            add(value, "semantic")
        for value in generate_candidates(sql, example, question, schema, {}):
            add(value, "rule")
        for origin, value in extra_candidates(sql, example, question, schema):
            add(value, origin)
        for origin,value in linked_queries(sql,question,example,schema):
            add(value,origin)
        for origin,value in mutations(sql,question,example,schema):
            add(value,origin)
    for value in synthesize(roots,question,example,schema):
        add(value,"synthesis")
    return candidates


def features(candidate, original, question, example, schema):
    sql = candidate["sql"]
    ast = parse(sql)
    q = question.lower()
    f = {"bias":1.0}
    f["anchor"] = float(candidate.get("anchor",False))
    f["origin_"+candidate["origin"]] = 1.0
    if ast is None:
        return {**f,"invalid":1.0}
    f["edit"] = 1-difflib.SequenceMatcher(None, re.sub(r"\s+"," ",original.lower()), re.sub(r"\s+"," ",sql.lower()), autojunk=False).ratio()
    f["length"] = math.log1p(len(sql))/8
    tables = list(ast.find_all(exp.Table))
    f["joins"] = min(len(list(ast.find_all(exp.Join))),8)/4
    f["subqueries"] = min(len(list(ast.find_all(exp.Subquery))),8)/4
    f["selects"] = min(len(list(ast.find_all(exp.Select))),8)/4
    f["set"] = float(isinstance(ast, exp.SetOperation))
    f["except"] = float(bool(ast.find(exp.Except)))
    f["intersect"] = float(bool(ast.find(exp.Intersect)))
    f["distinct"] = float(bool(ast.args.get("distinct")))
    f["group"] = float(bool(ast.args.get("group")))
    f["limit"] = float(bool(ast.args.get("limit")))
    f["order"] = float(bool(ast.args.get("order")))
    f["having"] = float(bool(ast.args.get("having")))
    counts=list(ast.find_all(exp.Count))
    f["count_distinct"] = float(any(isinstance(c.this,exp.Distinct) for c in counts))
    f["count_star"] = float(any(isinstance(c.this,exp.Star) for c in counts))
    f["count_col"] = float(any(isinstance(c.this,exp.Column) for c in counts))
    f["lower"] = float(bool(ast.find(exp.Lower)))
    f["like"] = float(bool(ast.find(exp.Like)))
    f["negative"] = float(bool(ast.find(exp.Not)) or bool(ast.find(exp.NEQ)) or f["except"])
    f["empty"] = float(example["row_count"]==0)
    f["expected_cols"] = min(len(example["columns"]),8)/4
    f["projection_count_error"] = abs(len(ast.selects)-len(example["columns"]))/4
    target_sigs=[]
    for label in example['columns']:
        try:target_sigs.append(signature(sqlglot.parse_one(label,read='sqlite')))
        except (sqlglot.errors.SqlglotError,ValueError):target_sigs.append(label.lower())
    actual_sigs=[signature(e) for e in ast.selects]
    f['projection_signature_errors']=sum(a!=b for a,b in zip(target_sigs,actual_sigs))+abs(len(target_sigs)-len(actual_sigs))
    f['projection_signature_exact']=float(target_sigs==actual_sigs)
    for agg in ['avg','sum','min','max','count']:
        expected_agg=any(s.startswith(agg+'(') for s in target_sigs)
        actual_agg=any(s.startswith(agg+'(') for s in actual_sigs)
        f['expected_'+agg+'_conflict']=float(expected_agg!=actual_agg)
    expected = " ".join(example["columns"]).lower()
    f["expected_count_star"] = float(bool(re.search(r"count\s*\(\s*\*",expected)))
    f["expected_distinct"] = float("distinct" in expected)
    f["expected_count_star_match"] = f["expected_count_star"] * f["count_star"]
    f["expected_count_star_conflict"] = f["expected_count_star"] * f["count_distinct"]
    tablemap={t["name"].lower():t for t in schema}
    aliases={t.alias_or_name.lower():t.name.lower() for t in tables}
    f["unknown_tables"] = sum(t.name.lower() not in tablemap for t in tables)
    invalid=0
    try:
        for scope in traverse_scope(ast):
            local={alias.lower():t.name.lower() for alias,t in scope.sources.items() if isinstance(t,exp.Table)}
            for col in scope.columns:
                if col.table and col.table.lower() in local:
                    meta=tablemap.get(local[col.table.lower()])
                    if meta and col.name.lower() not in {c['name'].lower() for c in meta['columns']}:invalid+=1
    except (sqlglot.errors.SqlglotError,ValueError,AttributeError):
        pass
    f["unknown_cols"] = min(invalid,8)
    f["tautology"] = sum(e.this.sql().lower()==e.expression.sql().lower() for e in ast.find_all(exp.EQ))
    f["left_join"] = float(any(j.side=="LEFT" for j in ast.find_all(exp.Join)))
    literals=[l.this.lower() for l in ast.find_all(exp.Literal) if l.is_string]
    f["literal_unmentioned"] = min(sum(v not in q for v in literals if v and not re.fullmatch(r"\d+",v)),5)/3
    quoted=re.findall(r"['\"]([^'\"]+)['\"]",q)
    f["quoted_missing"] = sum(not any(v in val or val in v for val in literals) for v in quoted)/3
    qwords=words(q)
    tablewords=set().union(*(words(t.name.replace("_"," ")) for t in tables)) if tables else set()
    f["table_overlap"] = len(qwords & tablewords)/max(1,len(tablewords))
    colwords=set().union(*(words(c.name.replace("_"," ")) for c in ast.find_all(exp.Column)))
    f["col_overlap"] = len(qwords & colwords)/max(1,len(colwords))
    qflags={"unique":bool(re.search(r"\b(distinct|unique|different)\b",q)),
            "negative":bool(re.search(r"\b(not|never|without|no)\b|don't|do not",q)),
            "group":bool(re.search(r"\b(each|per)\b",q)),
            "mode":bool(re.search(r"common|frequent",q)),
            "super":bool(re.search(r"most|least|highest|lowest|maximum|minimum|largest|smallest",q)),
            "count":bool(re.search(r"how many|number of|count",q)),
            "both":bool(re.search(r"\bboth\b",q)),
            "order":bool(re.search(r"order|sort|alphabetical",q))}
    for name,value in qflags.items():
        f["q_"+name]=float(value)
        f["anchor__"+name]=float(value)*f["anchor"]
    for term in ['average','total','maximum','minimum','recent','first','last','oldest','ascending','descending','contains','type','kind','before','after','every','either','neither']:
        f['q_word_'+term]=float(bool(re.search(r'\b'+term+r'\b',q)))
    for qname in qflags:
        for sqlname in ["distinct","count_distinct","group","order","limit","negative","except","intersect","left_join","joins","count_star","origin_original","origin_hint","origin_semantic","origin_distinct"]:
            f[qname+"__"+sqlname]=float(qflags[qname])*f.get(sqlname,0)
    for name in ["origin_original","origin_hint","origin_align","origin_semantic","origin_distinct","origin_case","origin_projection","origin_rule","joins","unknown_cols","distinct","count_distinct"]:
        f["empty__"+name]=f["empty"]*f.get(name,0)
    f["anchor__empty"]=f["anchor"]*f["empty"]
    return f


def default_score(candidate, original, question, example, schema):
    f=features(candidate,original,question,example,schema)
    return (2*f.get("origin_hint",0)+1*f.get("origin_align",0)+.5*f.get("origin_semantic",0)+f.get("origin_fk_link",0)+f.get('origin_qrule',0)
            -5*f.get("unknown_cols",0)-5*f.get("unknown_tables",0)-3*f.get("projection_count_error",0)
            -f.get("tautology",0)-.2*f.get("edit",0)+f.get("expected_count_star_match",0)
            -f.get("expected_count_star_conflict",0))
