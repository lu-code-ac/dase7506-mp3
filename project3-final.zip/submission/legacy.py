"""CPU-only v6: feedback, cached hints, schema-guided AST repair, and fallback.

Only observation/history are read. No benchmark files, databases, network,
grading references, or task-specific answers are accessed by this module.
"""

import re
import json
from pathlib import Path

import sqlglot
from sqlglot import exp
from sqlglot.errors import ParseError, TokenError
from repairs import generate_candidates, prefer_original, semantic_candidates, semantic_review_needed

MAX_SQL_BYTES = 16000


def candidate_sql(value):
    """Treat hints as untrusted SQL data; accept one read-only query only."""
    if not isinstance(value, str):
        return None
    sql = value.strip()
    fence = re.fullmatch(r"```(?:sql|sqlite)?\s*\n(.*?)\n```", sql, re.I | re.S)
    if fence:
        sql = fence.group(1).strip()
    if not sql or len(sql.encode("utf-8")) > MAX_SQL_BYTES:
        return None
    try:
        statements = sqlglot.parse(sql, read="sqlite")
        if len(statements) != 1 or not isinstance(statements[0], (exp.Select, exp.SetOperation)):
            return None
        forbidden = (exp.Insert, exp.Update, exp.Delete, exp.Create, exp.Drop, exp.Command, exp.Into)
        if any(isinstance(node, forbidden) for node in statements[0].walk()):
            return None
        key = statements[0].sql(dialect="sqlite", comments=False)
    except (ParseError, TokenError, RecursionError, ValueError):
        return None
    return sql, key


class FeedbackAgent:
    """Reconstruct state from history; safe to use with parallel task runners."""

    def __init__(self, inspect_matching_draft=True, use_rules=True):
        self.inspect_matching_draft = inspect_matching_draft
        self.use_rules = use_rules

    def act(self, observation):
        original = observation["issue_sql"]
        history = observation["history"]
        checks = [event for event in history if event["tool"] == "check"]
        question = observation["task"]["question"]
        passed = [e for e in checks if e["observation"].get("ok")
                  and e["observation"].get("matches_example")]
        original_passed = any(e["sql"] == original for e in passed)
        if original_passed and not self.inspect_matching_draft:
            return {"tool": "submit", "sql": original}
        hints_event = next((e for e in history if e["tool"] == "repair_hint"), None)
        hints = hints_event["observation"] if hints_event else []
        raw_candidates = []
        for value in hints:
            parsed = candidate_sql(value)
            if parsed is not None and parsed[0] not in raw_candidates:
                raw_candidates.append(parsed[0])
        raw_candidates.append(original)
        raw_keys = {parsed[1] for sql in raw_candidates if (parsed := candidate_sql(sql))}
        # A checked, generated repair has already survived the public verifier.
        for event in passed:
            parsed = candidate_sql(event["sql"])
            if parsed and parsed[1] not in raw_keys:
                return {"tool": "submit", "sql": event["sql"]}
        best = next((e["sql"] for e in passed if e["sql"] != original),
                    original if original_passed else None)
        if self.use_rules and best and original_passed and prefer_original(original, best, question):
            best = original
        if observation["remaining"] <= 0:
            return {"tool": "submit", "sql": best or original}
        if not any(event["sql"] == original for event in checks):
            return {"tool": "check", "sql": original}
        if hints_event is None:
            return {"tool": "repair_hint"}
        checked_strings = {e["sql"] for e in checks}
        seen = {parsed[1] for sql in checked_strings if (parsed := candidate_sql(sql))}
        if not any(e["sql"] != original for e in passed):
            for value in hints:
                parsed = candidate_sql(value)
                if parsed and parsed[0] not in checked_strings and parsed[1] not in seen:
                    return {"tool": "check", "sql": parsed[0]}
        if not self.use_rules:
            return {"tool": "submit", "sql": best or original}
        if best and not semantic_review_needed(best, question, observation["example"]):
            return {"tool": "submit", "sql": best}
        schema_event = next((e for e in history if e["tool"] == "schema"), None)
        if schema_event is None:
            return {"tool": "schema"}
        schema = schema_event["observation"]
        bases = [best] if best else raw_candidates
        for sql in bases:
            feedback = next((e["observation"] for e in checks if e["sql"] == sql), {})
            proposals = list(semantic_candidates(sql, observation["example"], question, schema))
            if best is None:
                proposals += list(generate_candidates(sql, observation["example"], question, schema, feedback))
            for value in proposals:
                parsed = candidate_sql(value)
                if parsed and parsed[0] not in checked_strings and parsed[1] not in seen:
                    return {"tool": "check", "sql": parsed[0]}
        return {"tool": "submit", "sql": best or original}


def create_agent(checkpoint=None):
    options = {} if checkpoint is None else json.loads(Path(checkpoint).read_text(encoding="utf-8"))
    if not isinstance(options, dict) or set(options) - {"inspect_matching_draft", "use_rules"}:
        raise ValueError("Unknown agent configuration")
    if any(type(value) is not bool for value in options.values()):
        raise ValueError("Agent options must be boolean")
    return FeedbackAgent(**options)
