"""Ranked search using only public tool observations and training-only weights."""
from legacy import candidate_sql
from search import pool, default_score, features
from ranker import score
from legacy import FeedbackAgent
from grounding import plan as grounding_plan, repair as grounding_repair
from linking import linked_queries
from constraints import penalty


class HybridAgent:
    def __init__(self,ranker="learned",margin=0,adaptive=False):
        self.legacy=FeedbackAgent()
        self.ranker=ranker
        self.margin=margin
        self.anchor=None
        self.candidates=None
        self.adaptive=adaptive
        self.searcher=None
        self.probe=None
        self.grounded=None
        self.probe_done=False

    def act(self,observation):
        if self.searcher is not None:return self.searcher.act(observation)
        schema_index=next((i for i,e in enumerate(observation['history']) if e['tool']=='schema'),None)
        if self.adaptive and self.anchor is None and schema_index is not None:
            attempted=any(e['tool']=='check' for e in observation['history'][schema_index+1:])
            if attempted and not any(e['tool']=='check' and e['observation'].get('matches_example') for e in observation['history']):
                self.searcher=RankedAgent('early')
                return self.searcher.act(observation)
        if self.anchor is None:
            action=self.legacy.act(observation)
            if action['tool']!='submit' or observation['remaining']==0:
                return action
            self.anchor=action['sql']
        checks=[e for e in observation['history'] if e['tool']=='check']
        schema_event=next((e for e in observation['history'] if e['tool']=='schema'),None)
        if schema_event is None:
            if observation['remaining']:return {'tool':'schema'}
            return {'tool':'submit','sql':self.anchor}
        schema=schema_event['observation']
        if not self.probe_done:
            self.probe_done=True
            if observation['remaining']>=2:
                self.probe=grounding_plan(self.anchor,observation['task']['question'],schema)
                if self.probe:return {'tool':'execute','sql':self.probe['sql']}
        if self.probe:
            event=next((e for e in observation['history'] if e['tool']=='execute' and e['sql']==self.probe['sql']),None)
            if event and self.grounded is None:
                self.grounded=grounding_repair(self.probe,event['observation'],observation['task']['question']) or ''
                if self.grounded:
                    linked=list(linked_queries(self.grounded,observation['task']['question'],observation['example'],schema))
                    if linked:self.grounded=linked[0][1]
            if self.grounded:
                checked_grounded=next((e for e in checks if e['sql']==self.grounded),None)
                if checked_grounded and checked_grounded['observation'].get('matches_example'):
                    return {'tool':'submit','sql':self.grounded}
                if not checked_grounded and observation['remaining']:
                    return {'tool':'check','sql':self.grounded}
        if self.candidates is None:
            hints=next((e['observation'] for e in observation['history'] if e['tool']=='repair_hint'),[])
            original=observation['issue_sql'];question=observation['task']['question'];example=observation['example']
            self.candidates=pool(original,hints,question,example,schema)
            self.candidates.sort(key=lambda c:default_score(c,original,question,example,schema),reverse=True)
            self.candidates=self.candidates[:24]
            parsed=candidate_sql(self.anchor)
            anchor_key=parsed[1] if parsed else self.anchor
            target=next((c for c in self.candidates if c['key']==anchor_key),None)
            if target is None:
                target={'sql':self.anchor,'key':anchor_key,'origin':'anchor'}
                self.candidates.append(target)
            target['anchor']=True
            anchor_features=features(target,original,question,example,schema)
            for c in self.candidates:c['anchor_features']=anchor_features
            for c in self.candidates:
                c['score']=score(c,original,question,example,schema,self.ranker)
                c['score']-=penalty(c['sql'],question,example,schema)
            target['score']+=self.margin
            self.candidates.sort(key=lambda c:c['score'],reverse=True)
        checked={}
        for e in checks:
            parsed=candidate_sql(e['sql'])
            if parsed:checked[parsed[1]]=e
        for c in self.candidates:
            e=checked.get(c['key'])
            if e:
                if e['observation'].get('matches_example'):
                    return {'tool':'submit','sql':e['sql']}
            elif observation['remaining']:
                return {'tool':'check','sql':c['sql']}
        return {'tool':'submit','sql':self.anchor}


class RankedAgent:
    def __init__(self, ranker="learned"):
        self.ranker=ranker
        self.candidates=None

    def act(self, observation):
        history=observation['history']
        original=observation['issue_sql']
        checks=[e for e in history if e['tool']=='check']
        if not checks:
            return {'tool':'check','sql':original} if observation['remaining'] else {'tool':'submit','sql':original}
        hint=next((e for e in history if e['tool']=='repair_hint'),None)
        if hint is None and observation['remaining']:
            return {'tool':'repair_hint'}
        schema_event=next((e for e in history if e['tool']=='schema'),None)
        if schema_event is None and observation['remaining']:
            return {'tool':'schema'}
        if self.candidates is None:
            schema=schema_event['observation'] if schema_event else []
            self.candidates=pool(original,hint['observation'] if hint else [],
                                 observation['task']['question'],observation['example'],schema)
            self.candidates.sort(key=lambda c:default_score(c,original,observation['task']['question'],observation['example'],schema),reverse=True)
            self.candidates=self.candidates[:24]
            for item in self.candidates:
                item['score']=score(item,original,observation['task']['question'],observation['example'],schema,self.ranker)
            self.candidates.sort(key=lambda c:c['score'],reverse=True)
        checked={}
        for event in checks:
            parsed=candidate_sql(event['sql'])
            if parsed:
                checked[parsed[1]]=event
        for candidate in self.candidates:
            event=checked.get(candidate['key'])
            if event:
                if event['observation'].get('ok') and event['observation'].get('matches_example'):
                    return {'tool':'submit','sql':event['sql']}
            elif observation['remaining']:
                return {'tool':'check','sql':candidate['sql']}
        for event in checks:
            if event['observation'].get('ok') and event['observation'].get('matches_example'):
                return {'tool':'submit','sql':event['sql']}
        return {'tool':'submit','sql':original}
