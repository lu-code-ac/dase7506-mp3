"""Necessary language/output constraints, independent of benchmark identities."""
import re
import sqlglot
from sqlglot import exp
from repairs import signature


def penalty(sql,question,example,schema=None):
    try:tree=sqlglot.parse_one(sql,read='sqlite')
    except (sqlglot.errors.SqlglotError,ValueError):return 3.
    q=re.sub(r"['\"][^'\"]*['\"]",' value ',question.lower())
    value=0.
    # Alphabetical order refers to a text value, not a numeric surrogate key.
    if 'alphabetical' in q and tree.args.get('order'):
        for item in tree.args['order'].expressions:
            if isinstance(item.this,exp.Column) and re.search(r'(?:^|_)id$',item.this.name,re.I):value+=4
    # A complete person's name does not belong in a single first/last-name
    # field when the schema represents those parts separately.
    aliases={t.alias_or_name.lower():t.name.lower() for t in tree.find_all(exp.Table)}
    fields={s['name'].lower():{re.sub('[^a-z]','',c['name'].lower()) for c in s['columns']} for s in (schema or [])}
    first={'fname','firstname','individualfirstname'};last={'lname','lastname','surname','individuallastname'}
    if not re.search(r'\b(first|last|given|family|sur)\s*name\b',q):
        for pred in tree.find_all(exp.EQ):
            col,lit=pred.this,pred.expression
            if isinstance(col,exp.Lower):col=col.this
            if not isinstance(col,exp.Column) or not isinstance(lit,exp.Literal) or not lit.is_string:continue
            name=re.sub('[^a-z]','',col.name.lower());parts=re.findall('[a-z]+',lit.this.lower())
            owner_fields=fields.get(aliases.get(col.table.lower()),set()) if col.table else set().union(*fields.values()) if fields else set()
            if len(parts)==2 and name in first|last and first&owner_fields and last&owner_fields:value+=4
    if len(tree.selects)!=len(example['columns']):value+=1
    for label,actual in zip(example['columns'],tree.selects):
        try:expected=sqlglot.parse_one(label,read='sqlite')
        except (sqlglot.errors.SqlglotError,ValueError):continue
        if isinstance(expected,exp.AggFunc) and signature(expected)!=signature(actual):value+=1
    negative=bool(re.search(r'\b(never|without)\b|\bnot\b|don.t|do not',q))
    if negative:
        neg_sql=bool(tree.find(exp.Not) or tree.find(exp.NEQ) or tree.find(exp.Except))
        neg_value=any(l.is_string and l.this.lower() in ('no','false','n') for l in tree.find_all(exp.Literal))
        # A negated comparison can legitimately be expressed with <= or >=.
        neg_comparison=bool(re.search(r'not\s+(?:more|less|older|younger|higher|lower|above|below|greater)',q))
        if not neg_sql and not neg_value and not neg_comparison:value+=1
    if re.search(r'\b(?:most|least)\s+common\b|\bmost\s+frequent\b',q):
        if not tree.find(exp.Group) or not tree.find(exp.Count):value+=1
    if re.search(r'\bboth\b',q) and not (tree.find(exp.Intersect) or tree.find(exp.Having) or tree.find(exp.Exists)):
        for node in tree.find_all(exp.In):
            if len(node.expressions)==2 and all(isinstance(v,exp.Literal) for v in node.expressions):value+=1;break
    return value
