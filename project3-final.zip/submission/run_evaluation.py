"""Run the unchanged official CLI in UTF-8 and retain commands, logs, and hashes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time


def snapshot(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file() and "__pycache__" not in p.parts}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--official-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--split", choices=("train", "validation", "test"), default="validation")
    parser.add_argument("--baseline", action="store_true")
    parser.add_argument("--method", type=Path, default=Path(__file__).with_name("submission.py"))
    parser.add_argument("--checkpoint", type=Path)
    args = parser.parse_args()
    official = args.official_root.resolve()
    out = args.output_dir.resolve()
    if out.is_relative_to(official):
        parser.error("Keep results outside the official package")
    if Path(args.label).name != args.label or args.label in (".", ".."):
        parser.error("label must be a filename prefix")
    out.mkdir(parents=True, exist_ok=True)
    before = snapshot(official)
    released = json.loads((official / "PACKAGE_MANIFEST.json").read_text(encoding="utf-8"))
    modified = [name for name, info in released["files"].items()
                if before.get(str(Path(name))) != info["sha256"]]
    if modified:
        raise ValueError("Official package differs from its release manifest: " + repr(modified))
    env = dict(os.environ, PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1")
    env["PYTHONPATH"] = str(args.method.resolve().parent)
    prefix = args.split if args.label == "final" else f"{args.label}-{args.split}"
    predictions = out / f"{prefix}.json"
    score = out / f"{prefix}-score.json"
    commands = [[sys.executable, "-m", "mp3_sql.check_data"],
                [sys.executable, "-m", "mp3_sql.predict", "--split", args.split,
                 "--workers", "4", "--output", str(predictions)]]
    if not args.baseline:
        commands[-1] += ["--method", str(args.method.resolve())]
        if args.checkpoint:
            commands[-1] += ["--checkpoint", str(args.checkpoint.resolve())]
    commands.append([sys.executable, "-m", "mp3_sql.score", "--split", args.split,
                     "--workers", "4", "--predictions", str(predictions), "--output", str(score)])
    record = {"python": sys.version, "platform": platform.platform(), "workers": 4,
              "encoding": "UTF-8", "split": args.split, "baseline": args.baseline,
              "official_root": str(official), "runs": []}
    if not args.baseline:
        record["method_sha256"] = hashlib.sha256(args.method.read_bytes()).hexdigest()
    success = False
    try:
        for i, command in enumerate(commands):
            started = time.perf_counter()
            result = subprocess.run(command, cwd=official, env=env, capture_output=True,
                                    text=True, encoding="utf-8", errors="replace")
            log = out / f"{args.label}-{args.split}-{i}.log"
            log.write_text(result.stdout + result.stderr, encoding="utf-8")
            record["runs"].append({"command": command, "returncode": result.returncode,
                                   "wall_seconds": time.perf_counter() - started, "log": log.name})
            print(result.stdout, end="")
            if result.stderr:
                print(result.stderr, end="", file=sys.stderr)
            if result.returncode:
                break
        success = len(record["runs"]) == len(commands) and all(r["returncode"] == 0 for r in record["runs"])
    finally:
        record["official_files_unchanged"] = before == snapshot(official)
        record["official_file_count"] = len(before)
        record["success"] = success and record["official_files_unchanged"]
        (out / f"{args.label}-{args.split}-run.json").write_text(
            json.dumps(record, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if not record["success"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
