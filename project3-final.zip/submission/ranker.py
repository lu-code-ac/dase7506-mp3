"""Small offline linear ranker; contains no benchmark identifiers or answers."""
import json
from pathlib import Path
from search import features, default_score

_MODEL = None
_EARLY = None


def load_model():
    global _MODEL
    if _MODEL is None:
        path = Path(__file__).with_name("ranker-model.json")
        _MODEL = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    return _MODEL


def override_value(model,values):
    if model['kind']=='override_ensemble':
        scores=[override_value(member,values) for member in model['members']]
        return sum(scores)/len(scores) if model.get('aggregation')=='mean' else max(scores)
    if model['kind']=='override_tree':
        vector=[values.get(n,0) for n in model['features']];value=0
        for tree in model['trees']:
            node=tree
            while 'value' not in node:node=node['left'] if vector[node['feature']]<=node['threshold'] else node['right']
            value+=node['value']
    else:
        value=sum(w*(values.get(n,0)-m)/s for n,w,m,s in zip(model['features'],model['weights'],model['means'],model['scales']))
    return value-model['threshold']


def score(candidate, original, question, example, schema, mode="learned"):
    global _EARLY
    if mode == "heuristic":
        return default_score(candidate, original, question, example, schema)
    if mode=='early':
        if _EARLY is None:_EARLY=json.loads(Path(__file__).with_name('early-model.json').read_text(encoding='utf-8'))
        model=_EARLY
    else:model = load_model()
    values = features(candidate, original, question, example, schema)
    if model.get("kind") in ("override","override_tree","override_ensemble"):
        if candidate.get("anchor"):return 0
        if "anchor_features" in candidate:
            anchor=candidate['anchor_features']
            for name in set(values)|set(anchor):
                values['delta_'+name]=values.get(name,0)-anchor.get(name,0)
            return override_value(model,values)-5*values.get('unknown_cols',0)-5*values.get('unknown_tables',0)
        while model.get('kind') in ('override','override_tree','override_ensemble'):model=model['fallback']
    if model.get("kind")=="forest":
        vector=[values.get(name,0) for name in model["features"]]
        total=model.get("base",0)
        for tree in model["trees"]:
            node=tree
            while "value" not in node:
                node=node["left"] if vector[node["feature"]]<=node["threshold"] else node["right"]
            total+=node["value"]
        return total-5*values.get("unknown_cols",0)-5*values.get("unknown_tables",0)
    value = sum(weight * (values.get(name, 0)-mean)/scale for name, weight, mean, scale in
                zip(model.get("features", []), model.get("weights", []), model.get("means", []), model.get("scales", [])))
    # SQL schema violations are not acceptable even when absent from the fit set.
    value -= 5*values.get("unknown_cols", 0)+5*values.get("unknown_tables", 0)
    return value
