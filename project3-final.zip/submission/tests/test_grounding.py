import unittest
from grounding import plan,repair


class GroundingTests(unittest.TestCase):
    def test_enum_uses_only_observed_values_mentioned_in_question(self):
        schema=[{'name':'events','columns':[{'name':'phase','type':'TEXT'}],'foreign_keys':[]}]
        query="SELECT phase FROM events WHERE phase IN ('A1','B2')"
        probe=plan(query,'Events in Alpha and Beta?',schema)
        self.assertIsNotNone(probe)
        sql=repair(probe,{'ok':True,'rows':[['Alpha'],['Beta'],['Gamma']]},'Events in Alpha and Beta?')
        self.assertIn("'Alpha', 'Beta'",sql)
        self.assertNotIn('Gamma',sql)

    def test_no_observed_match_keeps_no_candidate(self):
        schema=[{'name':'events','columns':[{'name':'phase','type':'TEXT'}],'foreign_keys':[]}]
        probe=plan("SELECT phase FROM events WHERE phase='A1'",'Events in Alpha?',schema)
        self.assertIsNone(repair(probe,{'ok':True,'rows':[['Beta']]},'Events in Alpha?'))


if __name__=='__main__':unittest.main()
