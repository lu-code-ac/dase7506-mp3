import unittest
import sqlglot
from repairs import align_projection

class AliasMetadataTests(unittest.TestCase):
    def test_alias_does_not_hide_wrong_output_expression(self):
        schema=[dict(name='branches',columns=[dict(name='id'),dict(name='name')])]
        t=sqlglot.parse_one('SELECT id AS name FROM branches')
        self.assertEqual(align_projection(t,['name'],schema).sql(),'SELECT branches.name FROM branches')

    def test_function_alias_does_not_hide_a_requested_raw_column(self):
        schema=[dict(name='farms',columns=[dict(name='total_horses')])]
        t=sqlglot.parse_one('SELECT SUM(total_horses) AS total_horses FROM farms')
        self.assertEqual(align_projection(t,['total_horses'],schema).sql(),'SELECT farms.total_horses FROM farms')

    def test_alias_without_a_schema_column_is_retained(self):
        schema=[dict(name='farms',columns=[dict(name='id')])]
        t=sqlglot.parse_one('SELECT COUNT(*) AS number FROM farms')
        self.assertEqual(align_projection(t,['number'],schema).sql(),t.sql())
