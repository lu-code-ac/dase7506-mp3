import unittest
from constraints import penalty

class LanguageConstraintTests(unittest.TestCase):
    def test_alphabetical_surrogate_key_is_penalized(self):
        q='Supplier names in alphabetical order of their addresses.'
        ex={'columns':['name']}
        self.assertGreater(penalty('SELECT name FROM suppliers ORDER BY address_id',q,ex),
                           penalty('SELECT name FROM suppliers ORDER BY address_details',q,ex))
    def test_full_name_does_not_belong_in_last_name_alone(self):
        schema=[dict(name='people',columns=[dict(name='first_name'),dict(name='last_name'),dict(name='age')])]
        q='Age of the person named Alex Lee?';ex={'columns':['age']}
        self.assertGreater(penalty("SELECT p.age FROM people p WHERE p.last_name='Alex Lee'",q,ex,schema),
                           penalty("SELECT p.age FROM people p WHERE p.first_name='Alex' AND p.last_name='Lee'",q,ex,schema))
    def test_explicit_multiword_surname_is_allowed(self):
        schema=[dict(name='people',columns=[dict(name='first_name'),dict(name='last_name')])]
        q='People with last name Van Dyke?'
        self.assertEqual(penalty("SELECT last_name FROM people WHERE last_name='Van Dyke'",q,{'columns':['last_name']},schema),0)
