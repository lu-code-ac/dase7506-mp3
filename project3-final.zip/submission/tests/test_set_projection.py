import unittest
from search import features
from constraints import penalty


class SetProjectionTests(unittest.TestCase):
    def test_set_query_has_left_output_columns(self):
        for op in ['INTERSECT','EXCEPT','UNION']:
            query=f'SELECT name FROM t {op} SELECT name FROM t'
            c={'sql':query,'origin':'both'}
            ex={'columns':['name'],'row_count':0}
            f=features(c,'SELECT name FROM t','Show names.',ex,[])
            self.assertEqual(f['projection_count_error'],0)
            self.assertEqual(f['projection_signature_errors'],0)
            self.assertEqual(penalty(query,'Show names.',ex),0)


if __name__=='__main__':unittest.main()
