import unittest
import sqlglot
from repairs import repair_joins
from linking import linked_queries


class RoleTests(unittest.TestCase):
    def test_valid_second_foreign_key_is_preserved(self):
        schema=[{'name':'people','columns':[{'name':'id'},{'name':'name'}],'foreign_keys':[]},
                {'name':'edges','columns':[{'name':'source_id'},{'name':'target_id'}],
                 'foreign_keys':[{'table':'people','from':'source_id','to':'id'},{'table':'people','from':'target_id','to':'id'}]}]
        sql='SELECT p.name FROM people p JOIN edges e ON p.id=e.target_id'
        self.assertIn('p.id = e.target_id',repair_joins(sqlglot.parse_one(sql),schema).sql())
        for _,candidate in linked_queries(sql,'Names of recipients.',{'columns':['name']},schema):
            self.assertNotIn('p.id = e.source_id',candidate)

    def test_self_join_is_not_collapsed(self):
        schema=[{'name':'people','columns':[{'name':'id'},{'name':'name'}],'foreign_keys':[]}]
        sql='SELECT a.name, b.name FROM people a JOIN people b ON a.id=b.id'
        self.assertEqual(list(linked_queries(sql,'Both names.',{'columns':['name','name']},schema)),[])


if __name__=='__main__':unittest.main()
