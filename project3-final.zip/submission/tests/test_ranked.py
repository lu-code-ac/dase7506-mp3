import copy
import unittest
from controller import RankedAgent
from mp3_sql.environment import rollout,replay
from test_submission import SyntheticTools,ROW


class Tools(SyntheticTools):
    def schema(self,row):
        return []


class RankedTests(unittest.TestCase):
    def test_hint_prerequisite_budget_and_replay(self):
        tools=Tools(['SELECT 1'],matches=['SELECT 1'])
        pred=rollout(copy.deepcopy(ROW),tools,RankedAgent('heuristic'))
        self.assertEqual(pred['sql'],'SELECT 1')
        self.assertEqual([e['tool'] for e in pred['trace']][:3],['check','repair_hint','schema'])
        self.assertLessEqual(pred['tool_calls'],8)
        self.assertEqual(replay(ROW,tools,pred),pred['sql'])

    def test_empty_budget_preserves_checked_answer(self):
        tools=Tools(['SELECT 1'],matches=[ROW['issue_sql']])
        for budget in (0,1,2,3):
            pred=rollout(copy.deepcopy(ROW),tools,RankedAgent('heuristic'),budget)
            self.assertEqual(pred['sql'],ROW['issue_sql'])
            self.assertEqual(replay(ROW,tools,pred,budget),ROW['issue_sql'])

    def test_duplicate_alias_does_not_crash_pool(self):
        tools=Tools(['SELECT 1 FROM x AS a JOIN y AS a ON a.id=a.id'])
        pred=rollout(copy.deepcopy(ROW),tools,RankedAgent('heuristic'))
        self.assertLessEqual(pred['tool_calls'],8)


if __name__=='__main__':unittest.main()
