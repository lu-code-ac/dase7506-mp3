import unittest
import sqlglot
from repairs import align_projection, fix_columns, prefer_original, repair_joins, semantic_candidates


class RepairTests(unittest.TestCase):
    def test_reorder_projection_and_keep_filter(self):
        tree = sqlglot.parse_one("SELECT b, a FROM t WHERE a > 2")
        fixed = align_projection(tree, ["a", "b"], [])
        self.assertEqual(fixed.sql(), "SELECT a, b FROM t WHERE a > 2")

    def test_drop_extra_aggregate_and_preserve_order_expression(self):
        tree = sqlglot.parse_one("SELECT a, COUNT(*) AS n FROM t GROUP BY a ORDER BY n DESC LIMIT 3")
        fixed = align_projection(tree, ["a"], [])
        self.assertEqual(fixed.sql(), "SELECT a FROM t GROUP BY a ORDER BY COUNT(*) DESC LIMIT 3")

    def test_column_owner_repair(self):
        schema = [{"name": "songs", "columns": [{"name": "file_id"}]},
                  {"name": "files", "columns": [{"name": "duration"}, {"name": "file_id"}]}]
        tree = sqlglot.parse_one("SELECT AVG(s.duration) FROM songs s JOIN files f ON s.file_id = f.file_id")
        self.assertIn("AVG(f.duration)", fix_columns(tree, schema).sql())

    def test_preserve_duplicate_semantics(self):
        self.assertTrue(prefer_original("SELECT name FROM t", "SELECT DISTINCT name FROM t", "Show names."))
        self.assertFalse(prefer_original("SELECT name FROM t", "SELECT DISTINCT name FROM t", "Show distinct names."))

    def test_correlated_reference_is_not_rebound(self):
        schema = [{"name": "parent", "columns": [{"name": "id"}]},
                  {"name": "child", "columns": [{"name": "id"}]}]
        query = sqlglot.parse_one("SELECT p.id FROM parent p WHERE EXISTS(SELECT 1 FROM child c WHERE c.id=p.id)")
        self.assertIn("c.id = p.id", fix_columns(query, schema).sql())

    def test_bridge_table_is_added_from_foreign_keys(self):
        schema = [{"name": "items", "foreign_keys": []},
                  {"name": "orders", "foreign_keys": []},
                  {"name": "line_items", "foreign_keys": [
                      {"table": "items", "from": "item_id", "to": "id"},
                      {"table": "orders", "from": "order_id", "to": "id"}]}]
        query = sqlglot.parse_one("SELECT i.name FROM items i JOIN orders o ON i.id=o.id")
        fixed = repair_joins(query, schema).sql()
        self.assertIn("JOIN line_items ON i.id = line_items.item_id", fixed)
        self.assertIn("JOIN orders AS o ON line_items.order_id = o.id", fixed)

    def test_count_repair_keeps_having_distinct(self):
        schema = [{"name": "t", "columns": [{"name": "kind", "type": "TEXT"}], "foreign_keys": []}]
        example = {"columns": ["count(*)"], "row_count": 1}
        queries = list(semantic_candidates("SELECT COUNT(DISTINCT kind) FROM t HAVING COUNT(DISTINCT kind)>1", example, "How many rows?", schema))
        query = sqlglot.parse_one(queries[0])
        from sqlglot import exp
        self.assertIsInstance(query.args["having"].find(exp.Count).this, exp.Distinct)
        self.assertIsInstance(query.expressions[0].this, exp.Star)

    def test_negation_uses_set_exclusion(self):
        schema = [{"name": "p", "columns": [{"name": "name", "type": "TEXT"}], "foreign_keys": []}]
        example = {"columns": ["name"], "row_count": 1}
        queries = list(semantic_candidates("SELECT name FROM p WHERE name NOT IN ('morning')", example, "Names never in morning?", schema))
        self.assertTrue(any("EXCEPT" in q for q in queries))


if __name__ == "__main__":
    unittest.main()
