import unittest
from linking import linked_queries
from synthesis import synthesize


class LinkingTests(unittest.TestCase):
    def test_missing_column_owner_and_fk_join_are_recovered(self):
        schema=[{'name':'products','columns':[{'name':'id'},{'name':'color_id'}],
                 'foreign_keys':[{'table':'colors','from':'color_id','to':'id'}]},
                {'name':'colors','columns':[{'name':'id'},{'name':'description'}],'foreign_keys':[]}]
        proposals=list(linked_queries("SELECT COUNT(DISTINCT p.id) FROM products p WHERE p.description='white'",
                                       "How many products are white?",{'columns':['count(*)']},schema))
        self.assertTrue(any('JOIN colors' in sql and 'COUNT(*)' in sql and 'colors.description' in sql for _,sql in proposals))

    def test_universal_comparison_uses_extremum(self):
        proposals=list(linked_queries("SELECT age FROM person WHERE age > (SELECT age FROM person WHERE job='engineer')",
                                       'Older than every engineer?',{'columns':['age']},[]))
        self.assertTrue(any('MAX(age)' in sql for _,sql in proposals))

    def test_synthesis_does_not_discard_quoted_filter(self):
        schema=[{'name':'items','columns':[{'name':'name','type':'TEXT'}],'foreign_keys':[]}]
        proposals=list(synthesize([],"Find items named 'red'.",{'columns':['name']},schema))
        self.assertEqual(proposals,[])


if __name__=='__main__':unittest.main()
