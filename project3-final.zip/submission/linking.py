"""Rebind public expressions and predicates through the schema's FK graph."""
import re
from collections import deque
import sqlglot
from sqlglot import exp


def linked_queries(sql,question,example,schema):
    try:tree=sqlglot.parse_one(sql,read='sqlite')
    except (sqlglot.errors.SqlglotError,ValueError):return
    if not isinstance(tree,exp.Select):return
    q=question.lower()
    # Universal comparisons require an extremum, not a multi-row scalar query.
    if re.search(r'\b(all|every)\b',q):
        universal=tree.copy();changed=False
        for comparison in universal.find_all(exp.Condition):
            if isinstance(comparison,(exp.GT,exp.GTE,exp.LT,exp.LTE)) and isinstance(comparison.expression,exp.Subquery):
                sub=comparison.expression.this
                if isinstance(sub,exp.Select) and len(sub.expressions)==1 and isinstance(sub.expressions[0],exp.Column):
                    agg=exp.Max if isinstance(comparison,(exp.GT,exp.GTE)) else exp.Min
                    sub.set('expressions',[agg(this=sub.expressions[0].copy())]);changed=True
        if changed:yield 'universal',universal.sql(dialect='sqlite')
    if tree.find(exp.Subquery):return
    physical=[t.name.lower() for t in tree.find_all(exp.Table)]
    if len(physical)!=len(set(physical)):
        # Reconstructing one table per physical name cannot represent self joins.
        return
    tables={t['name'].lower():t for t in schema}
    fields={name:{c['name'].lower():c['name'] for c in t['columns']} for name,t in tables.items()}
    original_alias={t.alias_or_name.lower():t.name.lower() for t in tree.find_all(exp.Table)}
    original_alias.update({t.name.lower():t.name.lower() for t in tree.find_all(exp.Table)})
    source=tree.args.get('from')
    root=source.this.name.lower() if source and isinstance(source.this,exp.Table) else ''
    if root not in tables:return
    projections=[]
    for label in example['columns']:
        try:item=sqlglot.parse_one(label,read='sqlite')
        except (sqlglot.errors.SqlglotError,ValueError):return
        if not isinstance(item,(exp.Column,exp.AggFunc)):return
        # A public label such as Name is ambiguous; retain a valid source from
        # the original projection before trying other schema matches.
        for col in item.find_all(exp.Column):
            prior=next((c for e in tree.expressions for c in e.find_all(exp.Column) if c.name.lower()==col.name.lower()),None)
            if prior and prior.table:col.set('table',prior.args.get('table').copy())
        projections.append(item)
    rebuilt=tree.copy();rebuilt.set('expressions',projections)
    rebuilt.set('joins',[])
    needed={root};failed=False
    aliases={}
    for alias,table in original_alias.items():
        if table in tables and table not in aliases:aliases[table]=alias
    aliases[root]=source.this.alias_or_name
    for col in rebuilt.find_all(exp.Column):
        owner=original_alias.get(col.table.lower(),'')
        if owner not in fields or col.name.lower() not in fields.get(owner,{}):
            owners=[name for name,cols in fields.items() if col.name.lower() in cols]
            if not owners:
                # ORDER BY aliases are handled by the existing projection.
                prior=next((e for e in tree.expressions if e.alias.lower()==col.name.lower()),None)
                if prior:
                    col.replace(prior.this.copy());continue
                failed=True;break
            owner=root if root in owners else next((o for o in owners if o in original_alias.values()),owners[0])
        needed.add(owner)
        alias=aliases.setdefault(owner,owner)
        col.set('table',exp.to_identifier(alias));col.set('this',exp.to_identifier(fields[owner][col.name.lower()]))
    if failed:return
    graph={}
    for name,t in tables.items():
        for fk in t.get('foreign_keys',[]):
            other=fk['table'].lower()
            graph.setdefault(name,[]).append((other,fk['from'],fk['to']))
            graph.setdefault(other,[]).append((name,fk['to'],fk['from']))
    for join in tree.args.get('joins',[]):
        on=join.args.get('on')
        if not isinstance(on,exp.EQ) or not isinstance(on.this,exp.Column) or not isinstance(on.expression,exp.Column):continue
        a,b=on.this,on.expression
        left,right=original_alias.get(a.table.lower()),original_alias.get(b.table.lower())
        if left is None or right is None:continue
        for edge_source,target,col,other_col in [(left,right,a.name,b.name),(right,left,b.name,a.name)]:
            edges=graph.get(edge_source,[])
            preferred=[edge for edge in edges if edge[0]==target and edge[1].lower()==col.lower() and edge[2].lower()==other_col.lower()]
            if preferred:graph[edge_source]=preferred+[edge for edge in edges if edge not in preferred]
    # Some released schemas declare no foreign keys. A valid existing join on
    # the same named field still supplies a relationship without guessing IDs.
    for join in tree.args.get('joins',[]):
        on=join.args.get('on')
        if not on:continue
        for eq in on.find_all(exp.EQ):
            if not isinstance(eq.this,exp.Column) or not isinstance(eq.expression,exp.Column):continue
            a,b=eq.this,eq.expression
            left=original_alias.get(a.table.lower());right=original_alias.get(b.table.lower())
            if left==right or left not in fields or right not in fields:continue
            if a.name.lower()!=b.name.lower():continue
            reachable={left};front=[left]
            while front:
                name=front.pop()
                for other,_,_ in graph.get(name,[]):
                    if other not in reachable:reachable.add(other);front.append(other)
            if right in reachable:continue
            if a.name.lower() in fields[left] and b.name.lower() in fields[right]:
                graph.setdefault(left,[]).append((right,a.name,b.name))
                graph.setdefault(right,[]).append((left,b.name,a.name))
    connected={root};joins=[]
    for target in sorted(needed-{root}):
        queue=deque((name,[]) for name in sorted(connected));seen=set(connected);path=None
        while queue:
            name,route=queue.popleft()
            if name==target:path=route;break
            if len(route)>=4:continue
            for other,col,othercol in graph.get(name,[]):
                if other not in seen:
                    seen.add(other);queue.append((other,route+[(name,col,other,othercol)]))
        if path is None:return
        for left,col,right,othercol in path:
            if right in connected:continue
            alias=aliases.setdefault(right,right)
            table=exp.to_table(tables[right]['name'])
            if alias.lower()!=right:table=table.as_(alias)
            on=exp.EQ(this=exp.column(col,table=aliases[left]),expression=exp.column(othercol,table=alias))
            joins.append(exp.Join(this=table,on=on));connected.add(right)
    rebuilt.set('joins',joins)
    yield 'fk_link',rebuilt.sql(dialect='sqlite')
    if not rebuilt.args.get('distinct') and re.search(r'\b(distinct|unique|different)\b',q):
        unique=rebuilt.copy();unique.set('distinct',exp.Distinct());yield 'fk_link',unique.sql(dialect='sqlite')
    folded=rebuilt.copy();changed=False
    for predicate in list(folded.find_all(exp.EQ)):
        if isinstance(predicate.this,exp.Column) and isinstance(predicate.expression,exp.Literal) and predicate.expression.is_string:
            predicate.set('this',exp.Lower(this=predicate.this.copy()))
            predicate.set('expression',exp.Literal.string(predicate.expression.this.lower()));changed=True
    if changed:yield 'fk_case',folded.sql(dialect='sqlite')

    # Both values of a relation must hold for the selected entity, potentially
    # on different rows. INTERSECT preserves that entity-level interpretation.
    if re.search(r'\bboth\b',q):
        pairs=[]
        for node in rebuilt.find_all(exp.In):
            if len(node.expressions)==2 and all(isinstance(v,exp.Literal) for v in node.expressions):
                pairs.append((node.this,node.expressions))
        quoted=re.findall(r"['\"]([^'\"]+)['\"]",question)
        if len(quoted)==2:
            eq=next((e for e in rebuilt.find_all(exp.EQ) if isinstance(e.expression,exp.Literal) and e.expression.is_string and e.expression.this in quoted),None)
            if eq:pairs.append((eq.this,[exp.Literal.string(v) for v in quoted]))
        for col,values in pairs:
            if any(e.find(exp.AggFunc) for e in rebuilt.expressions):continue
            sides=[]
            for value in values:
                side=rebuilt.copy();side.set('group',None);side.set('having',None);side.set('order',None);side.set('limit',None)
                side.set('where',exp.Where(this=exp.EQ(this=col.copy(),expression=value.copy())))
                sides.append(side)
            yield 'both',exp.Intersect(this=sides[0],expression=sides[1],distinct=True).sql(dialect='sqlite')
    if re.search(r'\b(never|without|not)\b|don.t|do not',q) and not any(e.find(exp.AggFunc) for e in rebuilt.expressions):
        # Only schema-supported literal predicates belong in the positive set.
        predicates=[e.copy() for e in rebuilt.find_all(exp.EQ) if isinstance(e.expression,exp.Literal)]
        if predicates:
            positive=rebuilt.copy();positive.set('where',exp.Where(this=exp.and_(*predicates)))
            positive.set('group',None);positive.set('having',None)
            if all(not c.table or c.table.lower()==aliases[root].lower() for e in rebuilt.expressions for c in e.find_all(exp.Column)):
                allrows=exp.select(*(e.copy() for e in rebuilt.expressions)).from_(source.this.copy())
                yield 'anti',exp.Except(this=allrows,expression=positive,distinct=True).sql(dialect='sqlite')
