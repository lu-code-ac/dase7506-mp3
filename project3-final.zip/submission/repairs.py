"""General SQL AST repairs using only public example metadata and tool schema."""
import difflib
import re
from collections import deque

import sqlglot
from sqlglot import exp
from sqlglot.optimizer.scope import traverse_scope


def signature(node):
    node = node.unalias().copy()
    for column in node.find_all(exp.Column):
        column.set("table", None)
        column.set("db", None)
        column.set("catalog", None)
    return node.sql(dialect="sqlite", comments=False).lower()


def align_projection(tree, expected, schema):
    """Match output expressions to public column metadata, preserving row logic."""
    if not isinstance(tree, exp.Select) or any(isinstance(e, exp.Star) for e in tree.expressions):
        return tree
    selected = []
    used = set()
    sources = {t.alias_or_name.lower(): t.name.lower() for t in tree.find_all(exp.Table)}
    columns = {t["name"].lower(): {c["name"].lower() for c in t["columns"]} for t in schema}
    for label in expected:
        try:
            target = sqlglot.parse_one(label, read="sqlite")
        except (sqlglot.errors.SqlglotError, ValueError):
            return tree
        target_key = signature(target)
        real_column = isinstance(target,exp.Column) and any(
            target.name.lower() in columns.get(table,set()) for table in sources.values())
        choices = [(i, e) for i, e in enumerate(tree.expressions) if i not in used and
                   (signature(e) == target_key or (not real_column and e.alias_or_name.lower() == label.lower()))]
        if not choices and isinstance(target, exp.Count):
            choices = [(i, e) for i, e in enumerate(tree.expressions)
                       if i not in used and isinstance(e.unalias(), exp.Count)]
        if choices:
            index, expr = choices[0]
            used.add(index)
            selected.append(expr.copy())
        elif isinstance(target, exp.Column) and schema:
            owners = [alias for alias, table in sources.items()
                      if target.name.lower() in columns.get(table, set())]
            if not owners:
                return tree
            selected.append(exp.column(target.name, table=owners[0]))
        else:
            return tree
    if selected and len(selected) == len(expected):
        result = tree.copy()
        # ORDER BY an alias removed from SELECT must retain the original expression.
        removed = {e.alias.lower(): e.this for i, e in enumerate(tree.expressions)
                   if i not in used and isinstance(e, exp.Alias)}
        order = result.args.get("order")
        if order:
            for col in list(order.find_all(exp.Column)):
                if not col.table and col.name.lower() in removed:
                    col.replace(removed[col.name.lower()].copy())
        result.set("expressions", selected)
        return result
    return tree


def fix_columns(tree, schema):
    result = tree.copy()
    tables = {t["name"].lower(): {c["name"].lower(): c["name"] for c in t["columns"]}
              for t in schema}
    try:
        scopes = traverse_scope(result)
        for scope in scopes:
            sources = {alias.lower(): tables.get(table.name.lower(), {})
                       for alias, table in scope.sources.items() if isinstance(table, exp.Table)}
            projection_aliases = {e.alias.lower() for e in scope.expression.expressions if e.alias}
            for col in scope.columns:
                name = col.name.lower()
                owner = col.table.lower()
                # A qualified name outside this scope can be a correlated reference.
                if owner and owner not in sources:
                    continue
                # Moving an invalid JOIN operand can create a tautology. Repair
                # the relationship through foreign keys instead.
                if col.find_ancestor(exp.Join) is not None:
                    continue
                if not owner and name in projection_aliases:
                    continue
                owners = [alias for alias, fields in sources.items() if name in fields]
                if owner and name in sources.get(owner, {}):
                    continue
                if owners:
                    col.set("table", exp.to_identifier(owners[0]))
                    col.set("this", exp.to_identifier(sources[owners[0]][name]))
                elif sources:
                    possibilities = [(difflib.SequenceMatcher(None, name, field).ratio(), alias, field)
                                     for alias, fields in sources.items() for field in fields]
                    ratio, alias, field = max(possibilities, default=(0, "", ""))
                    if ratio >= .78:
                        col.set("table", exp.to_identifier(alias))
                        col.set("this", exp.to_identifier(sources[alias][field]))
    except (AttributeError, ValueError, sqlglot.errors.SqlglotError):
        return tree
    return result


def prefer_original(original, candidate, question):
    """Avoid adding DISTINCT when only the row multiplicity was changed."""
    try:
        a = sqlglot.parse_one(original, read="sqlite")
        b = sqlglot.parse_one(candidate, read="sqlite")
        if not isinstance(a, exp.Select) or not isinstance(b, exp.Select):
            return False
        if not a.args.get("distinct") and b.args.get("distinct"):
            b.set("distinct", None)
            return signature(a) == signature(b) and not re.search(r"\b(distinct|unique|different)\b", question, re.I)
        if a.args.get("distinct") and not b.args.get("distinct"):
            a.set("distinct", None)
            return signature(a) == signature(b) and bool(re.search(r"\b(distinct|unique|different)\b", question, re.I))
    except (sqlglot.errors.SqlglotError, ValueError):
        pass
    return False


def repair_joins(tree, schema):
    """Rebuild top-level relationships through short declared foreign-key paths."""
    result = tree.copy()
    source = result.args.get("from")
    if not source or not isinstance(source.this, exp.Table):
        return result
    graph = {}
    for table in schema:
        for fk in table.get("foreign_keys", []):
            left, right = table["name"].lower(), fk["table"].lower()
            graph.setdefault(left, []).append((right, fk["from"], fk["to"]))
            graph.setdefault(right, []).append((left, fk["to"], fk["from"]))
    connected = {source.this.name.lower(): source.this.alias_or_name}
    joins = []
    for join in result.args.get("joins", []):
        if not isinstance(join.this, exp.Table):
            joins.append(join.copy())
            continue
        target = join.this.name.lower()
        # Preserve the role encoded by an existing declared FK. Two different
        # columns can legitimately reference the same parent table.
        aliases={source.this.alias_or_name.lower():source.this.name.lower()}
        aliases.update({j.this.alias_or_name.lower():j.this.name.lower() for j in result.args.get('joins',[]) if isinstance(j.this,exp.Table)})
        on=join.args.get('on')
        valid_existing=False
        if isinstance(on,exp.EQ) and isinstance(on.this,exp.Column) and isinstance(on.expression,exp.Column):
            a,b=on.this,on.expression
            left,right=aliases.get(a.table.lower()),aliases.get(b.table.lower())
            valid_existing=any(other==right and col.lower()==a.name.lower() and other_col.lower()==b.name.lower()
                               for other,col,other_col in graph.get(left,[]))
        if valid_existing:
            joins.append(join.copy());connected[target]=join.this.alias_or_name
            continue
        if target in connected:
            joins.append(join.copy())
            continue
        queue = deque((name, []) for name in connected)
        seen = set(connected)
        path = None
        while queue:
            name, route = queue.popleft()
            if name == target:
                path = route
                break
            if len(route) >= 3:
                continue
            for other, col, other_col in graph.get(name, []):
                if other not in seen:
                    seen.add(other)
                    queue.append((other, route + [(name, col, other, other_col)]))
        if not path:
            joins.append(join.copy())
            connected[target] = join.this.alias_or_name
            continue
        for left, left_col, right, right_col in path:
            target_table = join.this.copy() if right == target else exp.to_table(right)
            alias = target_table.alias_or_name
            new_join = join.copy() if right == target else exp.Join()
            new_join.set("this", target_table)
            new_join.set("on", exp.EQ(this=exp.column(left_col, table=connected[left]),
                                       expression=exp.column(right_col, table=alias)))
            joins.append(new_join)
            connected[right] = alias
    result.set("joins", joins)
    return result


def semantic_review_needed(sql, question, example):
    q = question.lower()
    return (example["row_count"] == 0 or "distinct" in sql.lower() or
            bool(re.search(r"\b(never|not|exactly|two|three|alphabetical)\b", q)))


def semantic_candidates(sql, example, question, schema):
    try:
        tree = sqlglot.parse_one(sql, read="sqlite")
    except (sqlglot.errors.SqlglotError, ValueError):
        return
    if not isinstance(tree, exp.Select):
        return
    q = question.lower()
    tree = align_projection(fix_columns(tree, schema), example["columns"], schema)
    joined = repair_joins(tree, schema)
    source = joined.args.get("from")
    if not source or not isinstance(source.this, exp.Table):
        return
    base = source.this
    fields = next((t["columns"] for t in schema if t["name"].lower() == base.name.lower()), [])

    # Disambiguate sibling measures using words actually present in the question.
    measured = joined.copy()
    changed = False
    field_names = {c["name"].lower(): c["name"] for c in fields}
    for col in measured.find_all(exp.Column):
        for wanted, other in (("amount", "value"), ("value", "amount")):
            replacement = col.name.lower().replace(other, wanted)
            if wanted in q and other not in q and other in col.name.lower() and replacement in field_names:
                col.set("this", exp.to_identifier(field_names[replacement]))
                changed = True
    if changed:
        yield measured.sql(dialect="sqlite")

    # Explicit distinct requests and ordinary row counts have different semantics.
    if not re.search(r"\b(distinct|unique|different)\b", q):
        counted = joined.copy()
        changed = False
        for projection in counted.expressions:
            for count in projection.find_all(exp.Count):
                if isinstance(count.this, exp.Distinct):
                    count.set("this", exp.Star())
                    changed = True
        if changed:
            yield counted.sql(dialect="sqlite")

    # An exact cardinality named in the question differs from "at least N".
    if not re.search(r"at least|more than|minimum|or more|no less", q):
        exact = joined.copy()
        changed = False
        numbers = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5}
        for predicate in list(exact.find_all(exp.GTE)):
            if not predicate.find(exp.Count) or not isinstance(predicate.expression, exp.Literal):
                continue
            value = predicate.expression.this
            if any(str(n) == value and re.search(r"\b" + word + r"\s+\w+", q) for word, n in numbers.items()):
                predicate.replace(exp.EQ(this=predicate.this.copy(), expression=predicate.expression.copy()))
                changed = True
        if changed:
            yield exact.sql(dialect="sqlite")

    # Compare against the overall average, preserving the requested grouping.
    if re.search(r"\b(older|younger|above|below|higher|lower)\b.*\baverage\b", q):
        age = next((c["name"] for c in fields if c["name"].lower() == "age"), None)
        if age:
            avg = exp.select(exp.Avg(this=exp.column(age))).from_(base.name)
            cls = exp.LT if re.search(r"younger|below|lower", q) else exp.GT
            cond = cls(this=exp.column(age, table=base.alias_or_name), expression=exp.Subquery(this=avg))
            averaged = joined.copy().where(cond, append=True)
            yield averaged.sql(dialect="sqlite")

    # "for each X" specifies the grouping entity, rather than the selected key.
    each = re.search(r"\bfor each (\w+)(?:\s+(type|category|name))?", q)
    if each and joined.args.get("group"):
        stem = each.group(1).rstrip("s")
        suffix = each.group(2) or "id"
        field = next((c["name"] for c in fields if c["name"].lower() in (stem + "_" + suffix, stem + suffix)), None)
        if field:
            grouped = joined.copy()
            grouped.set("group", exp.Group(expressions=[exp.column(field, table=base.alias_or_name)]))
            yield grouped.sql(dialect="sqlite")

    # A count of the root entity grouped by a displayed attribute.
    threshold = re.search(r"\b(at least|more than|exactly) (\d+|one|two|three|four|five) (\w+)", q)
    if threshold and len(joined.expressions) == 1:
        op, number, noun = threshold.groups()
        number = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5}.get(number, number)
        noun = noun.replace("ies", "y").rstrip("s")
        if noun == base.name.lower().rstrip("s") and isinstance(joined.expressions[0].unalias(), exp.Column):
            item = joined.expressions[0].unalias().copy()
            cls = {"at least": exp.GTE, "more than": exp.GT, "exactly": exp.EQ}[op]
            grouped = exp.select(item).from_(base.copy()).group_by(item.copy())
            grouped = grouped.having(cls(this=exp.Count(this=exp.Star()), expression=exp.Literal.number(str(number))))
            yield grouped.sql(dialect="sqlite")

    # "all" without an explicit condition should not acquire an unrelated join.
    if re.search(r"\ball\b", q) and not re.search(r"\b(who|whose|where|with|that|which|in|from)\b", q):
        plain = exp.select(*(e.copy() for e in joined.expressions)).from_(base.copy())
        yield plain.sql(dialect="sqlite")

    # Unfiltered SUM over a single table must not be multiplied by unrelated joins.
    if not joined.args.get("where") and any(isinstance(e.unalias(), exp.Sum) for e in joined.expressions):
        owners = {c.table.lower() for e in joined.expressions for c in e.find_all(exp.Column) if c.table}
        sources = {t.alias_or_name.lower(): t for t in joined.find_all(exp.Table)}
        if len(owners) == 1 and next(iter(owners)) in sources:
            plain = exp.select(*(e.copy() for e in joined.expressions)).from_(sources[next(iter(owners))].copy())
            yield plain.sql(dialect="sqlite")

    # Never/not in a category means set exclusion, not a per-row inequality.
    if re.search(r"\bnever\b", q) and joined.args.get("where"):
        where = joined.args["where"].this
        positive = joined.copy()
        if isinstance(where, exp.Not) and isinstance(where.this, exp.In):
            positive.set("where", exp.Where(this=where.this.copy()))
        else:
            predicates = [p.copy() for p in where.flatten() if not p.find(exp.Exists)] if isinstance(where, exp.And) else []
            if not predicates:
                positive = None
            else:
                positive.set("where", exp.Where(this=exp.and_(*predicates)))
        if positive is not None:
            for eq in list(positive.find_all(exp.EQ)):
                if isinstance(eq.this, exp.Column) and isinstance(eq.expression, exp.Literal) and eq.expression.is_string:
                    eq.replace(exp.Like(this=eq.this.copy(), expression=eq.expression.copy()))
            all_rows = exp.select(*(e.copy() for e in joined.expressions)).from_(base.copy())
            yield exp.Except(this=all_rows, expression=positive, distinct=True).sql(dialect="sqlite")

    # A literal immediately naming the selected entity belongs to its name column.
    for eq in joined.find_all(exp.EQ):
        if not isinstance(eq.expression, exp.Literal) or not eq.expression.is_string:
            continue
        value = eq.expression.this
        stem = base.name.lower().rstrip("s").replace("_", " ")
        if value.lower() not in q or not re.search(re.escape(stem) + r"\s+(?:named\s+|called\s+)?['\"]?" + re.escape(value.lower()), q):
            continue
        name = next((c["name"] for c in fields if c["name"].lower().endswith("name")
                     and c["name"].lower() not in ("fname", "lname", "first_name", "last_name", "individual_first_name", "individual_last_name")), None)
        if name and not any(e.find(exp.AggFunc) for e in joined.expressions):
            plain = exp.select(*(e.copy() for e in joined.expressions)).from_(base.copy())
            plain = plain.where(exp.EQ(this=exp.column(name, table=base.alias_or_name), expression=eq.expression.copy()))
            yield plain.sql(dialect="sqlite")

    if "alphabetical" in q and "address" in q:
        for table in schema:
            for col in table["columns"]:
                if "address" in col["name"].lower() and any(t in col["type"].upper() for t in ("CHAR", "TEXT")):
                    ordered = joined.copy()
                    source_table = next((t for t in ordered.find_all(exp.Table) if t.name.lower() == table["name"].lower()), None)
                    if source_table is None:
                        source_table = exp.to_table(table["name"])
                        ordered = ordered.join(source_table.copy())
                        ordered = repair_joins(ordered, schema)
                    ordered.set("order", exp.Order(expressions=[exp.Ordered(this=exp.column(col["name"], table=source_table.alias_or_name))]))
                    yield ordered.sql(dialect="sqlite")
    yield joined.sql(dialect="sqlite")


def generate_candidates(sql, example, question, schema, feedback):
    """Yield high-confidence structural repairs before broader SQL mutations."""
    try:
        tree = sqlglot.parse_one(sql, read="sqlite")
    except (sqlglot.errors.SqlglotError, ValueError):
        return
    if not isinstance(tree, exp.Select):
        return
    expected = example["columns"]
    fixed = fix_columns(tree, schema)
    aligned = align_projection(fixed, expected, schema)
    yield aligned.sql(dialect="sqlite")
    yield fixed.sql(dialect="sqlite")

    # Numeric text storage can invalidate numeric-looking equality predicates.
    numeric = aligned.copy()
    changed = False
    for eq in numeric.find_all(exp.EQ):
        if isinstance(eq.this, exp.Column) and isinstance(eq.expression, exp.Literal):
            value = eq.expression
            if value.is_string and re.fullmatch(r"\d+(?:\.\d+)?", value.this):
                eq.set("this", exp.Cast(this=eq.this.copy(), to=exp.DataType.build("REAL")))
                eq.set("expression", exp.Literal.number(value.this))
                changed = True
    if changed:
        yield numeric.sql(dialect="sqlite")

    if feedback.get("row_count") == 0 and example["row_count"] > 0:
        broad = aligned.copy()
        changed = False
        for eq in list(broad.find_all(exp.EQ)):
            if isinstance(eq.this, exp.Column) and isinstance(eq.expression, exp.Literal):
                value = eq.expression
                if value.is_string and len(value.this) >= 3 and not value.this.isnumeric():
                    eq.replace(exp.Like(this=eq.this.copy(), expression=exp.Literal.string("%" + value.this + "%")))
                    changed = True
        if changed:
            yield broad.sql(dialect="sqlite")

    # Duplicates are part of the official result, so both forms need verification.
    if not aligned.args.get("group"):
        distinct = aligned.copy()
        distinct.set("distinct", None if distinct.args.get("distinct") else exp.Distinct())
        yield distinct.sql(dialect="sqlite")

    # COUNT(non-null key) and COUNT(*) are often interchangeable but not always.
    counted = aligned.copy()
    changed = False
    for count in counted.find_all(exp.Count):
        if not isinstance(count.this, exp.Star):
            count.set("this", exp.Star())
            changed = True
    if changed:
        yield counted.sql(dialect="sqlite")
