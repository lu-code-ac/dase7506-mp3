"""Read public enum values through an ordinary charged execute action."""
import re
import sqlglot
from sqlglot import exp


def plan(sql,question,schema):
    try:tree=sqlglot.parse_one(sql,read='sqlite')
    except (sqlglot.errors.SqlglotError,ValueError):return None
    aliases={t.alias_or_name.lower():t.name for t in tree.find_all(exp.Table)}
    tables={t['name'].lower():t for t in schema}
    q=question.lower()
    for predicate in tree.walk():
        values=[]
        if isinstance(predicate,exp.In) and not predicate.args.get('query'):values=predicate.expressions
        elif isinstance(predicate,exp.EQ):values=[predicate.expression]
        else:continue
        col=predicate.this
        if not isinstance(col,exp.Column) or not values or not all(isinstance(v,exp.Literal) and v.is_string for v in values):continue
        if all(v.this.lower() in ('yes','no','true','false') for v in values):continue
        if any(v.this.lower() and v.this.lower() in q for v in values):continue
        owners=[aliases[col.table.lower()]] if col.table.lower() in aliases else [t['name'] for t in schema if any(c['name'].lower()==col.name.lower() for c in t['columns'])]
        if len(owners)!=1:continue
        table=owners[0];meta=tables.get(table.lower())
        if not meta or col.name.lower() not in {c['name'].lower() for c in meta['columns']}:continue
        probe=exp.select(exp.column(col.name)).distinct().from_(table).limit(8)
        return {'sql':probe.sql(dialect='sqlite'),'column':col.sql(dialect='sqlite'),'predicate':predicate.sql(dialect='sqlite'),'old':sql}
    return None


def repair(probe,feedback,question):
    if not feedback.get('ok'):return None
    q=question.lower();values=[]
    for row in feedback.get('rows',[]):
        if len(row)==1 and isinstance(row[0],str) and row[0].strip():
            value=row[0]
            if re.search(r'(?<!\w)'+re.escape(value.strip().lower())+r'(?!\w)',q):values.append(value)
    if not values:return None
    tree=sqlglot.parse_one(probe['old'],read='sqlite')
    for predicate in tree.walk():
        if predicate.sql(dialect='sqlite')!=probe['predicate']:continue
        col=predicate.this.copy()
        if isinstance(predicate,exp.In) and len(values)==len(predicate.expressions):
            predicate.set('expressions',[exp.Literal.string(v) for v in values]);return tree.sql(dialect='sqlite')
        if isinstance(predicate,exp.EQ) and len(values)==1:
            predicate.set('expression',exp.Literal.string(values[0]));return tree.sql(dialect='sqlite')
    return None
