"""Additional generic repairs mined from training SQL structure differences."""
import re
import sqlglot
from sqlglot import exp


def mutations(sql,question,example,schema):
    try:tree=sqlglot.parse_one(sql,read='sqlite')
    except (sqlglot.errors.SqlglotError,ValueError):return
    if not isinstance(tree,exp.Select):return
    q=question.lower()
    # SQLite has no > ALL / < ALL syntax; a quantified comparison requires
    # the extremal member of the scalar subquery.
    quantified=tree.copy();changed=False
    for op in quantified.walk():
        if isinstance(op,(exp.GT,exp.GTE,exp.LT,exp.LTE)) and isinstance(op.expression,exp.All):
            sub=op.expression.this
            if isinstance(sub,exp.Select) and len(sub.expressions)==1:
                agg=exp.Max if isinstance(op,(exp.GT,exp.GTE)) else exp.Min
                sub=sub.copy();sub.set('expressions',[agg(this=sub.expressions[0].copy())])
                op.set('expression',exp.Subquery(this=sub));changed=True
    if changed:yield 'qrule',quantified.sql(dialect='sqlite')

    inner=tree.copy();changed=False
    for join in inner.args.get('joins',[]):
        if join.side=='LEFT':join.set('side',None);changed=True
    if changed:yield 'mutation',inner.sql(dialect='sqlite')
    group=tree.args.get('group')
    if group:
        nonagg=[e.unalias().copy() for e in tree.expressions if not e.find(exp.AggFunc)]
        if nonagg:
            grouped=tree.copy();grouped.set('group',exp.Group(expressions=nonagg))
            yield 'mutation',grouped.sql(dialect='sqlite')
        counted=tree.copy();changed=False
        for count in counted.find_all(exp.Count):
            if not isinstance(count.this,exp.Star):count.set('this',exp.Star());changed=True
        if changed:
            yield 'qrule',counted.sql(dialect='sqlite')
            if nonagg:
                counted.set('group',exp.Group(expressions=nonagg));yield 'qrule',counted.sql(dialect='sqlite')

    source=tree.args.get('from')
    if not source or not isinstance(source.this,exp.Table):return
    root=source.this;alias=root.alias_or_name.lower()
    where=tree.args.get('where')
    root_only=all(not c.table or c.table.lower()==alias for e in tree.expressions for c in e.find_all(exp.Column))
    # Convert a parent-level aggregate filter to IN so non-grouped details are
    # returned for every qualifying entity rather than one arbitrary row.
    if group and tree.args.get('having') and len(group.expressions)==1 and root_only and not any(e.find(exp.AggFunc) for e in tree.expressions):
        key=group.expressions[0]
        if isinstance(key,exp.Column) and (not key.table or key.table.lower()==alias):
            inside=tree.copy();inside.set('expressions',[key.copy()]);inside.set('order',None);inside.set('limit',None)
            outside=exp.select(*(e.copy() for e in tree.expressions)).from_(root.copy())
            outside=outside.where(exp.In(this=key.copy(),query=exp.Subquery(this=inside)))
            yield 'qrule',outside.sql(dialect='sqlite')

    if where and re.search(r'\b(not|never|without)\b|don.t',q) and root_only and not any(e.find(exp.AggFunc) for e in tree.expressions):
        positive=tree.copy();positive.set('distinct',None);positive.set('order',None);positive.set('limit',None)
        for join in positive.args.get('joins',[]):join.set('side',None)
        predicates=[]
        items=list(where.this.flatten()) if isinstance(where.this,exp.And) else [where.this]
        for item in items:
            if isinstance(item,exp.Is) and isinstance(item.expression,exp.Null):continue
            if isinstance(item,exp.NEQ):item=exp.EQ(this=item.this.copy(),expression=item.expression.copy())
            predicates.append(item.copy())
        positive.set('where',exp.Where(this=exp.and_(*predicates)) if predicates else None)
        allrows=exp.select(*(e.copy() for e in tree.expressions)).from_(root.copy())
        if positive.args.get('joins'):
            yield 'qrule',exp.Except(this=allrows,expression=positive,distinct=True).sql(dialect='sqlite')

    # Output metadata identifies a single-table origin/destination query even
    # when a draft introduced unrelated route tables.
    literals=[l.this for l in tree.find_all(exp.Literal) if l.is_string and l.this.lower() in q]
    from_values=[v for v in literals if re.search(r'\bfrom\s+[\"\']?'+re.escape(v.lower()),q)]
    to_values=[v for v in literals if re.search(r'\bto\s+[\"\']?'+re.escape(v.lower()),q)]
    if from_values and to_values:
        for table in schema:
            fields={c['name'].lower():c['name'] for c in table['columns']}
            first=next((fields[n] for n in ['origin','departure','source','source_city'] if n in fields),None)
            last=next((fields[n] for n in ['destination','arrival','destination_city'] if n in fields),None)
            if not first or not last:continue
            projection=[]
            for label in example['columns']:
                if label.lower() not in fields:break
                projection.append(exp.column(fields[label.lower()]))
            if len(projection)==len(example['columns']):
                route=exp.select(*projection).from_(table['name']).where(
                    exp.and_(exp.EQ(this=exp.column(first),expression=exp.Literal.string(from_values[0])),
                             exp.EQ(this=exp.column(last),expression=exp.Literal.string(to_values[0]))))
                yield 'qrule',route.sql(dialect='sqlite')
    if tree.args.get('order') and re.search(r'order|sort|ascending|alphabetical',q) and not re.search(r'descending|highest|greatest|most|latest|recent|largest',q):
        ascending=tree.copy()
        for item in ascending.args['order'].expressions:item.set('desc',False)
        yield 'qrule',ascending.sql(dialect='sqlite')
    if where:
        # Unrequested filters are candidates, never accepted without feedback.
        unfiltered=tree.copy();unfiltered.set('where',None);yield 'mutation',unfiltered.sql(dialect='sqlite')
