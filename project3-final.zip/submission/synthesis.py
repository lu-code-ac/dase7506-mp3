"""Construct small schema-supported queries from public output metadata."""
import re
import sqlglot
from sqlglot import exp


def tokens(s):
    return {w[:-3]+'y' if w.endswith('ies') else w[:-1] if w.endswith('s') else w
            for w in re.findall(r'[a-z]+',s.lower()) if len(w)>2}


def synthesize(roots,question,example,schema):
    q=question.lower();qtokens=tokens(q)
    expected=[]
    for label in example['columns']:
        try:item=sqlglot.parse_one(label,read='sqlite')
        except (sqlglot.errors.SqlglotError,ValueError):return
        if not isinstance(item,(exp.Column,exp.AggFunc)):return
        expected.append(item)
    asts=[]
    for sql in roots:
        try:asts.append(sqlglot.parse_one(sql,read='sqlite'))
        except (sqlglot.errors.SqlglotError,ValueError):pass
    candidates=[]
    for table in schema:
        fields={c['name'].lower():c for c in table['columns']}
        if any(c.name.lower() not in fields for e in expected for c in e.find_all(exp.Column)):continue
        overlap=len(tokens(table['name']) & qtokens)
        if not any(e.find(exp.Column) for e in expected) and overlap==0:continue
        if overlap==0 and len(expected)==1 and isinstance(expected[0],exp.Count):continue
        projection=[e.copy() for e in expected]
        for e in projection:
            for col in e.find_all(exp.Column):
                col.set('table',None)
        plain=exp.select(*projection).from_(table['name'])
        candidates.append((overlap,table,fields,plain))
    candidates.sort(key=lambda v:v[0],reverse=True)
    for overlap,table,fields,plain in candidates[:4]:
        filters=[]
        for ast in asts:
            where=ast.args.get('where')
            if not where:continue
            value=where.this.copy()
            cols=list(value.find_all(exp.Column))
            if value.find(exp.Subquery) or not cols or any(c.name.lower() not in fields for c in cols):continue
            for col in cols:col.set('table',None)
            filters.append(value)
        between=re.search(r'between\s+(\d{4})\s+and\s+(\d{4})',q)
        if between:
            year=next((c['name'] for c in table['columns'] if 'year' in c['name'].lower()),None)
            if year:filters.insert(0,exp.Between(this=exp.column(year),low=exp.Literal.number(between[1]),high=exp.Literal.number(between[2])))
        if filters:
            for value in filters:
                filtered=plain.copy().where(value)
                yield filtered.sql(dialect='sqlite')
                folded=filtered.copy()
                for eq in folded.find_all(exp.EQ):
                    if isinstance(eq.this,exp.Column) and isinstance(eq.expression,exp.Literal) and eq.expression.is_string:
                        eq.set('this',exp.Lower(this=eq.this.copy()))
                        eq.set('expression',exp.Literal.string(eq.expression.this.lower()))
                yield folded.sql(dialect='sqlite')
        else:
            # With no usable predicate, constrain synthesis to genuinely simple
            # requests. A quoted value or numeric bound must not be discarded.
            if re.search(r"['\"]|\b\d+\b|\b(who|whose|where|with|above|below|after|before|between)\b",q):continue
            yield plain.sql(dialect='sqlite')
            if re.search(r'\b(distinct|different|unique)\b',q) and not any(e.find(exp.AggFunc) for e in expected):
                distinct=plain.copy();distinct.set('distinct',exp.Distinct());yield distinct.sql(dialect='sqlite')
