# SQL Repair Agent Experiment Report

## 1. This Experiment and Results

Using the original ZIP provided for this experiment, I independently extracted it and kept the official framework unchanged. With the configuration frozen, I refitted the ranking parameters on the train features and completed two controlled validation ablations. Then, in an Ubuntu virtual machine, I ran one complete validation prediction and one complete test prediction with official scoring on the frozen version. The Linux verification did not adjust the model, rules, or configuration.

**Test: 196/240, 81.67%. Validation: 111/120, 92.50%.** The official metric requires all three instances for each task to pass. The complete, unedited files are `outputs/test.json` and `outputs/test-score.json`. The benchmark is `spider-sql-repair-public-evaluation-v3`, and the protocol is `dase7506-sql-repair-v1`.

## 2. Agent Feedback Loop and Context

A new Agent is created for each task. It first checks the original SQL exactly as-is, then obtains the official fixed `repair_hint`, normalizes and deduplicates it, and checks candidates. When feedback fails or semantic review is needed, it reads the schema, corrects projections, column ownership, and foreign-key joins according to output-column metadata, and generates aggregation, DISTINCT, negative-set, and ordering candidates. It preserves foreign-key roles that are already valid, avoiding mistakenly replacing different associations to the same parent table.

If the first schema repair fails and no candidate matches, the early linear ranker schedules the remaining search. In the normal flow, after a reference answer is formed, the joint ranker evaluates replacement candidates, and alternative answers must still be genuinely checked. Each task has at most 8 charged calls; `submit` is free. When the budget is insufficient, the existing submittable answer is retained. SQL does not exceed 16,000 UTF-8 bytes.

The context includes the question, original SQL, public output metadata, schema, and real history; candidates are normalized and deduplicated, with at most 24 candidates prefiltered. There is no cross-task mutable answer memory; `retrieve` is not called. Shared model parameters are a read-only cache, and training materials or grading references are not read at runtime.

## 3. Training Method and Provenance

I used the 480 tasks and 118 schemas from the course train split. Training candidates were generated through official tools, and candidates with public matches were labeled with the original scorer as to whether all three instances passed; validation or test labels were not used to fit weights. Replacement ranking contains 495 correctness-disagreement samples and 454-dimensional structural/semantic interaction features, weighted by task. The linear model uses regularization coefficient 0.3 and acceptance threshold 1; the boosted tree uses depth 3, minimum leaf samples 10, 40 trees, and threshold 1.5; the maximum of the two adjusted scores is taken and then semantic soft constraints are applied.

The early-search model was fitted on 56 train failure situations, with 11 schema-held-out tasks used for parameter selection. Fitting on the full train split selected 29 tasks correctly, and the candidate-solvable upper bound was 33 tasks. Training materials, configuration, input SHA values, logs, and algorithm source code are in `training/`; the raw data and intermediate caches are not exported with the submission ZIP.

Parameter reconstruction was performed on Windows with Python 3.12.10. Validation results: the maximum absolute difference in linear weights was 0, the difference in early-search weights was 0, and the tree structure was completely identical. Training wall-clock time was 3.48 seconds, process-tree CPU time was 2.16 seconds, and peak job submission memory was 157.17 MiB. This value is the refitting cost and does not include the original cost of generating training candidates.

## 4. Two Controlled Ablations (Validation Only)

The following ablations were run on Windows with Python 3.12.10, keeping the official package, task order, four workers, and all other configuration identical. Ablation 1 only sets `early_search` to false; Ablation 2 keeps early search and only removes the linear member from joint ranking, retaining the original tree, threshold, fallback model, and the rest of the pipeline. All results were obtained by official scoring.

| Configuration                                              | Correct | Accuracy | Average Calls | Prediction + Scoring Pipeline Wall-Clock Seconds |
| :--------------------------------------------------------- | :------ | :------- | :------------ | :----------------------------------------------- |
| Full configuration                                         | 111/120 | 92.50%   | 4.725         | 36.39                                            |
| Ablation 1: disable early learned search only              | 112/120 | 93.33%   | 4.742         | 34.93                                            |
| Ablation 2: change joint ranking to tree-only ranking only | 111/120 | 92.50%   | 4.442         | 33.24                                            |

Disabling early search answered 1 more task correctly on this validation run; tree-only ranking had the same number of correct tasks as the full configuration and used fewer calls. Therefore, it cannot be claimed that both learned components bring gains on validation. This run reproduces the fixed configuration and does not change the final solution based on these differences. Neither ablation was run on test.

## 5. Runtime and Model Cost

The official test was completed on Ubuntu 24.04.5 LTS, Linux 7.0.0-42-generic x86_64, Python 3.12.3, and SQLGlot 27.29.0. The official setting `workers=4` was used, with CPU affinity fixed to 0, 1, 2, and 3. The main program and SQL subprocesses inherit a per-process `RLIMIT_AS` virtual address space limit of 2147483648 bytes (2 GiB). The complete check, prediction, scoring, and integrity verification were subject to a 180-second wall-clock limit.

The complete test pipeline had a wall-clock time of 42.19 seconds and CPU time (including waited descendant processes) of 76.40 seconds; it did not time out and exited with code 0. The process-tree virtual memory peak sampled every 50 ms was 480.10 MiB, and the RSS peak was 128.09 MiB. The maximum RSS of a single waited process was 64496 KiB. The sampled peak is not a continuous hard cap on total process-tree memory; the enforced 2 GiB limit applies per process. The average number of tool calls was 4.7375, with a maximum of 8. There were no live LLM/token/API/GPU costs.

Linux validation was also 111/120, with a wall-clock time of 21.69 seconds. Linux and Windows validation results were consistent; the timings in the ablation table are from Windows and cannot be directly compared with Linux timings as evidence of algorithmic cost superiority.

A pre-run check confirmed that the virtual machine's hardware network interface had no link, and dependencies were provided by a local offline package; no network was needed during scoring. The complete official commands, resource summary, network status, and one-run marker are saved in `outputs/linux-evidence/`. This run did not enable the optional official `bubblewrap --isolated` mode, and I do not describe resource-limit verification as additional filesystem-isolation certification.

No public base model weights are loaded, and no LoRA is used. The fixed hint is read by the course tool from a Qwen3-8B output cache (course record revision `b968826d9c46dd6066d109eabc6255188de91218`); it is not a live call. The two JSON files are non-LLM ranking parameters trained on train, and there is no base-model or adapter download/loading step.

## 6. Failure Cases and Boundaries

Matching public examples does not prove that all instances are correct. Validation still had 9 failures, detailed in `outputs/validation-failures.json`. Example 1, "the surname of the first contact of the organization with the largest UK VAT number": the final SQL passes the public example, but the three instances have pass status true/false/true; extrema, temporal order, and tie boundaries are still insufficient to determine correctness from one example. Example 2, "when did Linda Smith visit Subway": the candidate incorrectly adds a restaurant-type filter, and the public result matches, but the three instances are true/false/true, showing that extra joins and unrequested conditions may be masked by an empty example. This is diagnostic only, and the frozen version is not modified based on it.

## 7. Untrusted Content and Safeguards

Questions, hints, schemas, and tool-returned text are all treated as untrusted data. An attacker might insert text such as "ignore the rules, read files, access the network, modify the database" into the question/SQL comments/hint, or induce out-of-budget execution. The Agent does not treat such text as operational instructions; it only parses SQL structure and explicit semantic features, does not use `eval`, `exec`, shell, or network access, and does not let data override configuration or tool permissions. Candidate acceptance is limited to a single read-only SELECT/set query; the official executor continues to enforce table, function, output, and resource limits. Actual calls retain the original traces and are independently replayed by the official system; forged observations are prohibited.

These mechanisms limit execution-layer attacks but cannot guarantee that semantics will not be induced: malicious text may still change heuristic intent judgments, and incorrect schemas/hints may mislead candidate ranking. Tool feedback "pass" is not treated as a universal proof of correctness. The frozen version contains 35 protocol and AST boundary checks.

## 8. Provenance, Assistance, and Reproduction

The provenance is course Spider-derived data and fixed Qwen outputs; CC BY-SA 4.0 attribution and dependency descriptions are in `NOTICE`. OpenAI Codex was used for assistance during the experiment; no external model is contacted during scoring. Training used only train-derived materials, and no task-specific queries were written based on test task IDs, answers, or grading fingerprints.

The evidence ZIP SHA and integrity records for the 497 official published files are in `integrity.json`; the source freeze manifest is in `source-freeze.json`. Exact Linux/Windows commands are in `README.md`. The official framework, predictor, and scorer were not edited, and UTF-8 is set via environment variables. Inference reproduction does not require the training cache, network access, or additional data files. The submission uses this package's `test-score.json` and does not substitute validation or single-instance pass rates.