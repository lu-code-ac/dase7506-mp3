"""Recompute delivered ranking weights from numerical TRAIN-only features.
Runtime inference does not require NumPy. See README for data provenance.
"""
import argparse,json,os
from pathlib import Path
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np
p=argparse.ArgumentParser()
p.add_argument('--agent',type=Path,required=True)
p.add_argument('--output-dir',type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parent
a.output_dir.mkdir(parents=True,exist_ok=True)
data=json.loads((root/'override-vectors.json').read_text(encoding='utf-8'))
assert data['training_split']=='train' and data['training_tasks']==480
names=data['features'];x=np.array(data['pair_vectors']);y=np.array(data['pair_labels']);tasks=np.array(data['pair_tasks'])
cuts=[np.unique(np.quantile(x[:,j],np.linspace(0,1,12)))[0:-1] for j in range(x.shape[1])]
bins=np.stack([np.searchsorted(cuts[j],x[:,j],side='left') for j in range(x.shape[1])],axis=1)
def grow(ids,g,h,depth,minleaf):
    totalg=g[ids].sum();totalh=h[ids].sum();leaf={'value':float(.12*totalg/(totalh+2))}
    if depth==0 or len(ids)<minleaf*2:return leaf
    best=None;bestgain=0
    for j,thresholds in enumerate(cuts):
        if not len(thresholds):continue
        b=bins[ids,j];size=len(thresholds)+1
        gs=np.cumsum(np.bincount(b,weights=g[ids],minlength=size))[:-1]
        hs=np.cumsum(np.bincount(b,weights=h[ids],minlength=size))[:-1]
        ns=np.cumsum(np.bincount(b,minlength=size))[:-1]
        gain=gs**2/(hs+2)+(totalg-gs)**2/(totalh-hs+2)-totalg**2/(totalh+2)
        gain[(ns<minleaf)|(len(ids)-ns<minleaf)]=-1;at=int(np.argmax(gain))
        if gain[at]>bestgain:bestgain=gain[at];best=(j,at)
    if best is None:return leaf
    j,at=best;left=bins[ids,j]<=at
    return {'feature':j,'threshold':float(cuts[j][at]),'left':grow(ids[left],g,h,depth-1,minleaf),'right':grow(ids[~left],g,h,depth-1,minleaf)}

def predict(tree,values):
    out=np.zeros(len(values))
    def visit(node,ids):
        if 'value' in node:out[ids]=node['value'];return
        left=values[ids,node['feature']]<=node['threshold'];visit(node['left'],ids[left]);visit(node['right'],ids[~left])
    visit(tree,np.arange(len(values)));return out

def fit(subset,depth,minleaf,n=80):
    ids=np.array([i for i,k in enumerate(tasks) if k in subset]);tt=tasks[ids]
    weights=np.zeros(len(y));weights[ids]=np.array([1/max(1,int((tt==k).sum())) for k in tt]);weights[ids]/=weights[ids].mean()
    trees=[];pred=np.zeros(len(y))
    for iteration in range(n):
        p=1/(1+np.exp(-np.clip(pred,-30,30)));g=(y-p)*weights;h=p*(1-p)*weights
        t=grow(ids,g,h,depth,minleaf);trees.append(t);pred+=predict(t,x)
    return trees

def fit_linear(mask,reg=.3):
    means=x[mask].mean(0);scales=x[mask].std(0);scales[scales<.05]=1
    zz=(x[mask]-means)/scales;yy=y[mask];tt=tasks[mask]
    weights=np.array([1/max(1,int((tt==k).sum())) for k in tt]);weights/=weights.mean()
    w=np.zeros(len(names));m=w.copy();v=w.copy()
    for step in range(1,701):
        p=1/(1+np.exp(-np.clip(zz@w,-30,30)));g=zz.T@((p-yy)*weights)/len(yy)+reg*w
        m=.9*m+.1*g;v=.999*v+.001*g*g;w-=.03*(m/(1-.9**step))/(np.sqrt(v/(1-.999**step))+1e-8)
    return w,means,scales

model=json.loads((a.agent/'ranker-model.json').read_text(encoding='utf-8'))
members=model['members'] if model['kind']=='override_ensemble' else [model]
differences={}
for member in members:
    assert member['features']==names
    if member['kind']=='override_tree':
        trees=fit(set(range(480)),3,10,40)
        differences['tree_structure_equal']=trees==member['trees']
        member['trees']=trees
    else:
        w,m,s=fit_linear(np.ones(len(y),dtype=bool),member['regularization'])
        differences['linear_max_abs_difference']=float(np.max(np.abs(w-np.array(member['weights']))))
        member.update(weights=w.tolist(),means=m.tolist(),scales=s.tolist())
(a.output_dir/'ranker-model.json').write_text(json.dumps(model,indent=2),encoding='utf-8')
data=json.loads((root/'early-vectors.json').read_text(encoding='utf-8'))
assert data['training_split']=='train'
names=data['features'];x=np.array(data['vectors']);y=np.array(data['labels']);groups=data['groups'];tasks=np.zeros(len(y),dtype=int)
for k,group in enumerate(groups):tasks[group]=k
mask=np.array([data['tasks'][k]['fold']!=0 for k in tasks])
means=x[mask].mean(0);scales=x[mask].std(0);scales[scales<.05]=1;z=(x-means)/scales
def fit_early(taskset,reg):
    mask=np.array([k in taskset for k in tasks]);zz=z[mask];yy=y[mask];diffs=[]
    for k in taskset:
        for a in groups[k]:
            if y[a]:
                for b in groups[k]:
                    if not y[b]:diffs.append(z[a]-z[b])
    d=np.array(diffs);w=np.zeros(len(names));m=w.copy();v=w.copy()
    for step in range(1,601):
        p=1/(1+np.exp(-np.clip(zz@w,-30,30)));g=zz.T@(p-yy)/len(yy)+reg*w
        if len(d):g-=d.T@(1/(1+np.exp(np.clip(d@w,-30,30))))/len(d)
        m=.9*m+.1*g;v=.999*v+.001*g*g;w-=.03*(m/(1-.9**step))/(np.sqrt(v/(1-.999**step))+1e-8)
    return w

model=json.loads((a.agent/'early-model.json').read_text(encoding='utf-8'))
assert model['features']==names
w=fit_early(set(range(len(groups))),model['regularization'])
differences['early_max_abs_difference']=float(np.max(np.abs(w-np.array(model['weights']))))
model.update(weights=w.tolist(),means=means.tolist(),scales=scales.tolist())
(a.output_dir/'early-model.json').write_text(json.dumps(model,indent=2),encoding='utf-8')
(a.output_dir/'verification.json').write_text(json.dumps(differences,indent=2),encoding='utf-8')
print(json.dumps(differences,indent=2))
