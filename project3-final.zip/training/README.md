# 非 LLM 排序器训练记录
训练仅使用官方 train（480 题、118 schema）生成的数值特征与多实例标签。override 使用495个分歧样本、454维特征；早期搜索使用56题。固定参数由训练记录与 config/model JSON 声明，本次重新拟合并验证参数一致。

train_models.py 为实际拟合代码；verification.json 和 training.log 为本次记录。input-hashes.json 标识训练输入，record-provenance.json 标识来源记录。训练数据与中间缓存按导出规则不随源码 ZIP 提供；推理复现只需要已导出的参数，不读取这些输入。若本地保留对应训练特征，将 override-vectors.json 和 early-vectors.json 放在该脚本旁，可执行：
`python training/train_models.py --agent submission --output-dir retrained`
